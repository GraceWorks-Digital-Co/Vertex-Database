#!/usr/bin/env python3
"""
Comprehensive Demo of Advanced Python Database Library
Showcases all features: CLI, indexing, transactions, and real-world usage
"""

import time
from datetime import datetime, timedelta
from database import (
    Database, Model, StringField, IntegerField, FloatField, 
    BooleanField, DateTimeField, QueryBuilder, IndexManager
)
from database.transactions import TransactionManager, TransactionState


class Lead(Model):
    """Business lead tracking model"""
    table_name = "leads"
    
    id = IntegerField(primary_key=True, nullable=False)
    name = StringField(max_length=100, nullable=False)
    email = StringField(max_length=100, nullable=False)
    company = StringField(max_length=100, nullable=True)
    status = StringField(max_length=20, default="new")  # new, contacted, qualified, closed
    value = FloatField(nullable=True)
    priority = IntegerField(default=2)  # 1=low, 2=medium, 3=high
    created_at = DateTimeField(default=datetime.now)
    updated_at = DateTimeField(default=datetime.now)
    follow_up_date = DateTimeField(nullable=True)


def demo_basic_operations():
    """Demonstrate basic CRUD operations"""
    print("🔧 BASIC CRUD OPERATIONS")
    print("=" * 50)
    
    db = Database("demo_leads.db")
    Model.set_database(db)
    Lead.create_table()
    
    # Create indexes
    db.create_index("leads", "status")
    db.create_index("leads", "priority")
    db.create_index("leads", "follow_up_date")
    
    # Insert leads
    leads_data = [
        {"name": "Alice Johnson", "email": "alice@company.com", "company": "TechCorp", "value": 50000, "priority": 3},
        {"name": "Bob Smith", "email": "bob@business.com", "company": "StartupInc", "value": 25000, "priority": 2},
        {"name": "Carol White", "email": "carol@enterprise.com", "company": "BigCorp", "value": 100000, "priority": 3},
        {"name": "David Brown", "email": "david@smallbiz.com", "company": "SmallBiz", "value": 10000, "priority": 1},
    ]
    
    print("📝 Adding leads...")
    for data in leads_data:
        lead = Lead(**data)
        lead.save()
        print(f"  ✅ Added: {lead.name} (${lead.value:,})")
    
    # Query leads
    print("\n🔍 Querying leads...")
    all_leads = QueryBuilder.select(Lead).order_by("value", desc=True).execute()
    for lead in all_leads:
        print(f"  {lead.name}: ${lead.value:,} ({lead.status})")
    
    # Update leads
    print("\n✏️ Updating lead status...")
    alice = QueryBuilder.select(Lead).where_eq("name", "Alice Johnson").first()
    if alice:
        alice.status = "contacted"
        alice.follow_up_date = datetime.now() + timedelta(days=3)
        alice.save()
        print(f"  ✅ Updated {alice.name} to {alice.status}")
    
    # Delete a lead
    print("\n🗑️ Deleting a lead...")
    david = QueryBuilder.select(Lead).where_eq("name", "David Brown").first()
    if david:
        david.delete()
        print(f"  ✅ Deleted {david.name}")
    
    db.close()


def demo_advanced_transactions():
    """Demonstrate advanced transaction management"""
    print("\n💰 ADVANCED TRANSACTIONS")
    print("=" * 50)
    
    db = Database("demo_transactions.db")
    Model.set_database(db)
    Lead.create_table()
    
    # Add some initial data
    lead1 = Lead(name="Transaction Test 1", email="test1@example.com", value=10000)
    lead2 = Lead(name="Transaction Test 2", email="test2@example.com", value=20000)
    lead1.save()
    lead2.save()
    
    print(f"Initial leads: {QueryBuilder.select(Lead).count()}")
    
    # Demonstrate explicit transaction control
    print("\n🔄 Testing explicit transactions...")
    
    # Successful transaction
    tx_id = db.begin_transaction()
    print(f"  📝 Started transaction: {tx_id}")
    
    try:
        # Update leads within transaction
        lead1.status = "qualified"
        lead1.save()
        
        lead2.status = "contacted"
        lead2.save()
        
        db.commit_transaction(tx_id)
        print(f"  ✅ Committed transaction {tx_id}")
    except Exception as e:
        print(f"  ❌ Failed: {e}")
        db.rollback_transaction(tx_id)
    
    # Failed transaction (rollback)
    tx_id = db.begin_transaction()
    print(f"  📝 Started transaction: {tx_id}")
    
    try:
        lead1.value = 999999  # This will work
        lead1.save()
        
        # Try to create an invalid lead (this should fail)
        invalid_lead = Lead(name="", email="invalid")  # Empty name should fail
        invalid_lead.save()
        
        db.commit_transaction(tx_id)
        print(f"  ✅ Committed transaction {tx_id}")
    except Exception as e:
        print(f"  ❌ Rolling back due to error: {e}")
        db.rollback_transaction(tx_id)
    
    # Check final state
    final_leads = QueryBuilder.select(Lead).execute()
    print(f"\nFinal leads: {len(final_leads)}")
    for lead in final_leads:
        value_str = f"${lead.value:,}" if lead.value is not None else "N/A"
        print(f"  {lead.name}: {lead.status} ({value_str})")
    
    # Show transaction stats
    stats = db.get_transaction_stats()
    print(f"\n📊 Transaction stats: {stats}")
    
    db.close()


def demo_indexing_performance():
    """Demonstrate indexing and query performance"""
    print("\n⚡ INDEXING & PERFORMANCE")
    print("=" * 50)
    
    db = Database("demo_performance.db")
    Model.set_database(db)
    Lead.create_table()
    
    # Create a large dataset
    print("📊 Creating large dataset...")
    start_time = time.time()
    
    for i in range(1000):
        lead = Lead(
            name=f"Lead {i}",
            email=f"lead{i}@example.com",
            company=f"Company {i % 100}",
            status=["new", "contacted", "qualified", "closed"][i % 4],
            value=1000 + (i * 100),
            priority=[1, 2, 3][i % 3]
        )
        lead.save()
    
    creation_time = time.time() - start_time
    print(f"  ✅ Created 1000 leads in {creation_time:.2f}s")
    
    # Test query performance without index
    print("\n🐌 Querying without index...")
    start_time = time.time()
    qualified_leads = QueryBuilder.select(Lead).where_eq("status", "qualified").execute()
    no_index_time = time.time() - start_time
    print(f"  Found {len(qualified_leads)} qualified leads in {no_index_time:.4f}s")
    
    # Create index
    print("\n📈 Creating index on status...")
    start_time = time.time()
    db.create_index("leads", "status")
    index_time = time.time() - start_time
    print(f"  ✅ Index created in {index_time:.4f}s")
    
    # Test query performance with index
    print("\n🚀 Querying with index...")
    start_time = time.time()
    qualified_leads = QueryBuilder.select(Lead).where_eq("status", "qualified").execute()
    with_index_time = time.time() - start_time
    print(f"  Found {len(qualified_leads)} qualified leads in {with_index_time:.4f}s")
    
    if with_index_time > 0:
        speedup = no_index_time / with_index_time
        print(f"  ⚡ Speedup: {speedup:.2f}x faster")
    
    # Test complex queries
    print("\n🔍 Testing complex queries...")
    
    # Range query on value
    high_value_leads = QueryBuilder.select(Lead).where_gte("value", 50000).execute()
    print(f"  High-value leads (>$50k): {len(high_value_leads)}")
    
    # Multiple conditions
    hot_leads = (QueryBuilder.select(Lead)
                 .where_eq("status", "qualified")
                 .where_gte("priority", 2)
                 .where_gte("value", 20000)
                 .execute())
    print(f"  Hot leads (qualified, high priority, >$20k): {len(hot_leads)}")
    
    # Show index statistics
    index_stats = db.get_index_stats()
    print(f"\n📊 Index statistics: {index_stats}")
    
    db.close()


def demo_cli_integration():
    """Demonstrate CLI integration"""
    print("\n💻 CLI INTEGRATION")
    print("=" * 50)
    
    # Import and use CLI functionality
    import subprocess
    import os
    
    cli_script = os.path.join(os.path.dirname(__file__), "cli.py")
    
    print("🚀 Testing CLI commands...")
    
    # Test adding a user via CLI
    try:
        result = subprocess.run([
            "python3", cli_script, "--db", "cli_demo.db", 
            "--command", 'add user {"name": "CLI User", "email": "cli@example.com", "age": 30}'
        ], capture_output=True, text=True, cwd=os.path.dirname(__file__))
        
        if result.returncode == 0:
            print(f"  ✅ CLI Add: {result.stdout.strip()}")
        else:
            print(f"  ❌ CLI Add failed: {result.stderr}")
    except Exception as e:
        print(f"  ❌ CLI error: {e}")
    
    # Test querying via CLI
    try:
        result = subprocess.run([
            "python3", cli_script, "--db", "cli_demo.db", 
            "--command", "list users"
        ], capture_output=True, text=True, cwd=os.path.dirname(__file__))
        
        if result.returncode == 0:
            print(f"  ✅ CLI Query: {len(result.stdout.splitlines())} lines returned")
        else:
            print(f"  ❌ CLI Query failed: {result.stderr}")
    except Exception as e:
        print(f"  ❌ CLI error: {e}")


def main():
    """Run comprehensive demo"""
    print("🎯 COMPREHENSIVE DATABASE LIBRARY DEMO")
    print("=" * 60)
    print("This demo showcases all advanced features:")
    print("• Basic CRUD operations")
    print("• Advanced transaction management")
    print("• Secondary indexing and performance")
    print("• CLI integration")
    print("• Real-world usage patterns")
    
    # Run demos
    demo_basic_operations()
    demo_advanced_transactions()
    demo_indexing_performance()
    demo_cli_integration()
    
    print("\n🎉 DEMO COMPLETE!")
    print("=" * 60)
    print("The Advanced Python Database Library provides:")
    print("✅ Full ORM functionality with validation")
    print("✅ Thread-safe connection pooling")
    print("✅ Advanced transaction management")
    print("✅ Secondary indexing for performance")
    print("✅ Interactive CLI interface")
    print("✅ Real-world task automation system")
    print("✅ Comprehensive error handling")
    print("✅ No external dependencies")


if __name__ == "__main__":
    main()

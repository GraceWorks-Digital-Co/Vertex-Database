"""
Test suite for the advanced Python database library
"""

import unittest
import tempfile
import os
from datetime import datetime

from database import Database, Model, StringField, IntegerField, FloatField, BooleanField, DateTimeField
from database.query import QueryBuilder
from database.exceptions import ValidationError, TransactionError, QueryError


class TestModel(Model):
    """Test model for unit tests"""
    table_name = "test_models"
    
    id = IntegerField(primary_key=True, nullable=False)
    name = StringField(max_length=50, nullable=False)
    value = IntegerField(default=0)
    active = BooleanField(default=True)


class TestDatabase(unittest.TestCase):
    """Test cases for database functionality"""
    
    def setUp(self):
        """Set up test environment"""
        self.temp_db = tempfile.NamedTemporaryFile(delete=False)
        self.temp_db.close()
        self.db = Database(self.temp_db.name)
        Model.set_database(self.db)
        TestModel.create_table()
    
    def tearDown(self):
        """Clean up test environment"""
        self.db.close()
        os.unlink(self.temp_db.name)
    
    def test_model_creation(self):
        """Test model instance creation"""
        model = TestModel(name="test", value=42)
        self.assertEqual(model.name, "test")
        self.assertEqual(model.value, 42)
        self.assertTrue(model.active)
    
    def test_model_validation(self):
        """Test field validation"""
        # Test string field length validation
        with self.assertRaises(ValidationError):
            TestModel(name="x" * 51)  # Exceeds max_length
        
        # Test integer field validation
        with self.assertRaises(ValidationError):
            TestModel(name="test", value="invalid")
    
    def test_model_save_and_retrieve(self):
        """Test saving and retrieving models"""
        model = TestModel(name="test_save", value=100)
        model.save()
        
        # Retrieve the saved model
        retrieved = QueryBuilder.select(TestModel).where_eq("name", "test_save").first()
        self.assertIsNotNone(retrieved)
        self.assertEqual(retrieved.name, "test_save")
        self.assertEqual(retrieved.value, 100)
        self.assertIsNotNone(retrieved.id)
    
    def test_model_update(self):
        """Test updating existing models"""
        model = TestModel(name="test_update", value=50)
        model.save()
        
        original_id = model.id
        model.value = 75
        model.save()
        
        # Verify update
        self.assertEqual(model.id, original_id)
        self.assertEqual(model.value, 75)
        
        retrieved = QueryBuilder.select(TestModel).where_eq("id", original_id).first()
        self.assertEqual(retrieved.value, 75)
    
    def test_model_delete(self):
        """Test deleting models"""
        model = TestModel(name="test_delete", value=25)
        model.save()
        model_id = model.id
        
        model.delete()
        
        # Verify deletion
        retrieved = QueryBuilder.select(TestModel).where_eq("id", model_id).first()
        self.assertIsNone(retrieved)
    
    def test_query_builder_select(self):
        """Test SELECT query builder"""
        # Insert test data
        models = [
            TestModel(name="model1", value=10),
            TestModel(name="model2", value=20),
            TestModel(name="model3", value=30)
        ]
        for model in models:
            model.save()
        
        # Test basic select
        all_models = QueryBuilder.select(TestModel).execute()
        self.assertEqual(len(all_models), 3)
        
        # Test where conditions
        filtered = QueryBuilder.select(TestModel).where_gt("value", 15).execute()
        self.assertEqual(len(filtered), 2)
        
        # Test ordering
        ordered = QueryBuilder.select(TestModel).order_by("value").execute()
        self.assertEqual(ordered[0].value, 10)
        self.assertEqual(ordered[2].value, 30)
        
        # Test limit
        limited = QueryBuilder.select(TestModel).limit(2).execute()
        self.assertEqual(len(limited), 2)
    
    def test_query_builder_insert(self):
        """Test INSERT query builder"""
        # Single insert
        insert_query = QueryBuilder.insert(TestModel).values(name="insert_test", value=99)
        row_id = insert_query.execute()
        self.assertIsNotNone(row_id)
        
        # Verify insertion
        model = QueryBuilder.select(TestModel).where_eq("id", row_id).first()
        self.assertEqual(model.name, "insert_test")
        self.assertEqual(model.value, 99)
        
        # Batch insert
        batch_data = [
            {"name": "batch1", "value": 1},
            {"name": "batch2", "value": 2},
            {"name": "batch3", "value": 3}
        ]
        QueryBuilder.insert(TestModel).batch_values(batch_data).execute()
        
        # Verify batch insertion
        count = QueryBuilder.select(TestModel).where_like("name", "batch%").count()
        self.assertEqual(count, 3)
    
    def test_query_builder_update(self):
        """Test UPDATE query builder"""
        # Insert test data
        model = TestModel(name="update_test", value=50)
        model.save()
        
        # Update using query builder
        updated_count = (QueryBuilder.update(TestModel)
                        .set("value", 75)
                        .set("active", False)
                        .where_eq("name", "update_test")
                        .execute())
        
        self.assertEqual(updated_count, 1)
        
        # Verify update
        updated_model = QueryBuilder.select(TestModel).where_eq("name", "update_test").first()
        self.assertEqual(updated_model.value, 75)
        self.assertFalse(updated_model.active)
    
    def test_query_builder_delete(self):
        """Test DELETE query builder"""
        # Insert test data
        models = [
            TestModel(name="delete1", value=10),
            TestModel(name="delete2", value=20),
            TestModel(name="keep", value=30)
        ]
        for model in models:
            model.save()
        
        # Delete using query builder
        deleted_count = (QueryBuilder.delete(TestModel)
                        .where_like("name", "delete%")
                        .execute())
        
        self.assertEqual(deleted_count, 2)
        
        # Verify deletion
        remaining = QueryBuilder.select(TestModel).execute()
        self.assertEqual(len(remaining), 1)
        self.assertEqual(remaining[0].name, "keep")
    
    def test_transaction_rollback(self):
        """Test transaction rollback on error"""
        initial_count = QueryBuilder.select(TestModel).count()
        
        try:
            with self.db.transaction() as conn:
                # This should succeed
                TestModel(name="success", value=1).save()
                
                # This should fail and cause rollback
                TestModel(name="x" * 100, value=2).save()  # Invalid: name too long
                
        except (ValidationError, TransactionError):
            pass  # Expected - transaction should rollback
        
        # Verify rollback
        final_count = QueryBuilder.select(TestModel).count()
        self.assertEqual(final_count, initial_count)
    
    def test_advanced_query_conditions(self):
        """Test advanced query conditions"""
        # Insert test data
        models = [
            TestModel(name="a", value=10, active=True),
            TestModel(name="b", value=20, active=False),
            TestModel(name="c", value=30, active=True),
            TestModel(name="d", value=40, active=False)
        ]
        for model in models:
            model.save()
        
        # Test IN condition
        in_results = QueryBuilder.select(TestModel).where_in("name", ["a", "c"]).execute()
        self.assertEqual(len(in_results), 2)
        
        # Test BETWEEN condition
        between_results = QueryBuilder.select(TestModel).where_between("value", 15, 35).execute()
        self.assertEqual(len(between_results), 2)
        
        # Test NULL conditions
        TestModel(name="null_test", value=None).save()
        null_results = QueryBuilder.select(TestModel).where_null("value").execute()
        self.assertEqual(len(null_results), 1)
        
        not_null_results = QueryBuilder.select(TestModel).where_not_null("value").execute()
        self.assertEqual(len(not_null_results), 4)
    
    def test_count_and_exists(self):
        """Test count and exists operations"""
        # Insert test data
        for i in range(5):
            TestModel(name=f"count_test_{i}", value=i).save()
        
        # Test count
        total_count = QueryBuilder.select(TestModel).count()
        self.assertEqual(total_count, 5)
        
        filtered_count = QueryBuilder.select(TestModel).where_gt("value", 2).count()
        self.assertEqual(filtered_count, 2)
        
        # Test exists
        exists_true = QueryBuilder.select(TestModel).where_eq("name", "count_test_1").exists()
        self.assertTrue(exists_true)
        
        exists_false = QueryBuilder.select(TestModel).where_eq("name", "nonexistent").exists()
        self.assertFalse(exists_false)


if __name__ == "__main__":
    unittest.main()

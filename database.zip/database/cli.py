#!/usr/bin/env python3
"""
Interactive CLI for the Advanced Python Database Library
Provides a command-line interface to interact with the database
"""

import sys
import json
import argparse
from typing import Dict, Any, List

from database import Database, Model, StringField, IntegerField, FloatField, BooleanField, DateTimeField
from database.query import QueryBuilder
from database.exceptions import ValidationError, QueryError
from datetime import datetime


# Define models for the CLI
class User(Model):
    table_name = "users"
    
    id = IntegerField(primary_key=True, nullable=False)
    name = StringField(max_length=100, nullable=False)
    email = StringField(max_length=100, unique=True, nullable=False)
    age = IntegerField(nullable=True)
    balance = FloatField(default=0.0)
    is_active = BooleanField(default=True)
    created_at = DateTimeField(default=datetime.now)


class Product(Model):
    table_name = "products"
    
    id = IntegerField(primary_key=True, nullable=False)
    name = StringField(max_length=100, nullable=False)
    category = StringField(max_length=50, nullable=True)
    price = FloatField(nullable=False)
    in_stock = BooleanField(default=True)
    created_at = DateTimeField(default=datetime.now)


class DatabaseCLI:
    """Interactive CLI for database operations"""
    
    def __init__(self, db_path: str = "cli_database.db"):
        self.db = Database(db_path)
        Model.set_database(self.db)
        self._init_tables()
    
    def _init_tables(self):
        """Initialize database tables"""
        User.create_table()
        Product.create_table()
    
    def run_interactive(self):
        """Run interactive CLI mode"""
        print("🗄️  Advanced Python Database CLI")
        print("Type 'help' for commands or 'quit' to exit")
        print("=" * 50)
        
        while True:
            try:
                command = input("\n> ").strip()
                if not command:
                    continue
                
                if command.lower() in ['quit', 'exit', 'q']:
                    print("Goodbye! 👋")
                    break
                
                self._execute_command(command)
            
            except KeyboardInterrupt:
                print("\nGoodbye! 👋")
                break
            except Exception as e:
                print(f"❌ Error: {e}")
    
    def _execute_command(self, command: str):
        """Execute a CLI command"""
        parts = command.split()
        if not parts:
            return
        
        cmd = parts[0].lower()
        
        if cmd == 'help':
            self._show_help()
        elif cmd == 'add':
            self._add_record(parts[1:])
        elif cmd == 'list' or cmd == 'show':
            self._list_records(parts[1:])
        elif cmd == 'query':
            self._query_records(parts[1:])
        elif cmd == 'update':
            self._update_record(parts[1:])
        elif cmd == 'delete':
            self._delete_record(parts[1:])
        elif cmd == 'stats':
            self._show_stats()
        else:
            print(f"❌ Unknown command: {cmd}. Type 'help' for available commands.")
    
    def _show_help(self):
        """Show help information"""
        help_text = """
📚 Available Commands:

📝 ADD RECORDS:
  add user {"name": "John", "email": "john@example.com", "age": 25}
  add product {"name": "Laptop", "category": "Electronics", "price": 999.99}

📋 LIST RECORDS:
  list users
  list products
  show users
  show products

🔍 QUERY RECORDS:
  query users where age > 20
  query products where price < 100
  query users where is_active = true
  query products where category = "Electronics"

✏️ UPDATE RECORDS:
  update user 1 {"age": 26}
  update product 2 {"price": 899.99}

🗑️ DELETE RECORDS:
  delete user 1
  delete product 2

📊 STATISTICS:
  stats

❓ HELP:
  help
        """
        print(help_text)
    
    def _add_record(self, args: List[str]):
        """Add a new record"""
        if len(args) < 2:
            print("❌ Usage: add <table> <json_data>")
            return
        
        table = args[0].lower()
        try:
            data = json.loads(' '.join(args[1:]))
        except json.JSONDecodeError as e:
            print(f"❌ Invalid JSON: {e}")
            return
        
        try:
            if table == 'user' or table == 'users':
                user = User(**data)
                user.save()
                print(f"✅ Added user: {user.name} (ID: {user.id})")
            
            elif table == 'product' or table == 'products':
                product = Product(**data)
                product.save()
                print(f"✅ Added product: {product.name} (ID: {product.id})")
            
            else:
                print(f"❌ Unknown table: {table}")
        
        except ValidationError as e:
            print(f"❌ Validation error: {e}")
        except Exception as e:
            print(f"❌ Error adding record: {e}")
    
    def _list_records(self, args: List[str]):
        """List all records in a table"""
        if not args:
            print("❌ Usage: list <table>")
            return
        
        table = args[0].lower()
        
        try:
            if table == 'user' or table == 'users':
                users = QueryBuilder.select(User).execute()
                self._display_users(users)
            
            elif table == 'product' or table == 'products':
                products = QueryBuilder.select(Product).execute()
                self._display_products(products)
            
            else:
                print(f"❌ Unknown table: {table}")
        
        except Exception as e:
            print(f"❌ Error listing records: {e}")
    
    def _query_records(self, args: List[str]):
        """Query records with conditions"""
        if len(args) < 4 or args[1].lower() != 'where':
            print("❌ Usage: query <table> where <condition>")
            print("Example: query users where age > 20")
            return
        
        table = args[0].lower()
        condition_str = ' '.join(args[2:])
        
        try:
            if table == 'user' or table == 'users':
                query = QueryBuilder.select(User)
                query = self._apply_condition(query, condition_str)
                users = query.execute()
                print(f"🔍 Found {len(users)} users:")
                self._display_users(users)
            
            elif table == 'product' or table == 'products':
                query = QueryBuilder.select(Product)
                query = self._apply_condition(query, condition_str)
                products = query.execute()
                print(f"🔍 Found {len(products)} products:")
                self._display_products(products)
            
            else:
                print(f"❌ Unknown table: {table}")
        
        except Exception as e:
            print(f"❌ Error querying records: {e}")
    
    def _apply_condition(self, query, condition_str: str):
        """Apply WHERE conditions to a query"""
        # Parse simple conditions like "age > 20" or "name = John"
        parts = condition_str.split()
        if len(parts) >= 3:
            field = parts[0]
            operator = parts[1]
            value = ' '.join(parts[2:])
            
            # Remove quotes from string values
            if value.startswith('"') and value.endswith('"'):
                value = value[1:-1]
            elif value.startswith("'") and value.endswith("'"):
                value = value[1:-1]
            
            # Convert numeric values
            try:
                if '.' in value:
                    value = float(value)
                else:
                    value = int(value)
            except ValueError:
                pass  # Keep as string
            
            # Convert boolean values
            if isinstance(value, str) and value.lower() in ['true', 'false']:
                value = value.lower() == 'true'
            
            # Apply the appropriate condition
            if operator == '=':
                query = query.where_eq(field, value)
            elif operator == '>':
                query = query.where_gt(field, value)
            elif operator == '>=':
                query = query.where_gte(field, value)
            elif operator == '<':
                query = query.where_lt(field, value)
            elif operator == '<=':
                query = query.where_lte(field, value)
            elif operator.lower() == 'like':
                query = query.where_like(field, value)
            else:
                print(f"❌ Unsupported operator: {operator}")
        
        return query
    
    def _update_record(self, args: List[str]):
        """Update a record"""
        if len(args) < 3:
            print("❌ Usage: update <table> <id> <json_data>")
            return
        
        table = args[0].lower()
        try:
            record_id = int(args[1])
            data = json.loads(' '.join(args[2:]))
        except (ValueError, json.JSONDecodeError) as e:
            print(f"❌ Invalid input: {e}")
            return
        
        try:
            if table == 'user' or table == 'users':
                user = QueryBuilder.select(User).where_eq("id", record_id).first()
                if user:
                    for key, value in data.items():
                        setattr(user, key, value)
                    user.save()
                    print(f"✅ Updated user {record_id}: {user.name}")
                else:
                    print(f"❌ User with ID {record_id} not found")
            
            elif table == 'product' or table == 'products':
                product = QueryBuilder.select(Product).where_eq("id", record_id).first()
                if product:
                    for key, value in data.items():
                        setattr(product, key, value)
                    product.save()
                    print(f"✅ Updated product {record_id}: {product.name}")
                else:
                    print(f"❌ Product with ID {record_id} not found")
            
            else:
                print(f"❌ Unknown table: {table}")
        
        except ValidationError as e:
            print(f"❌ Validation error: {e}")
        except Exception as e:
            print(f"❌ Error updating record: {e}")
    
    def _delete_record(self, args: List[str]):
        """Delete a record"""
        if len(args) < 2:
            print("❌ Usage: delete <table> <id>")
            return
        
        table = args[0].lower()
        try:
            record_id = int(args[1])
        except ValueError:
            print("❌ Invalid ID")
            return
        
        try:
            if table == 'user' or table == 'users':
                user = QueryBuilder.select(User).where_eq("id", record_id).first()
                if user:
                    user.delete()
                    print(f"✅ Deleted user {record_id}: {user.name}")
                else:
                    print(f"❌ User with ID {record_id} not found")
            
            elif table == 'product' or table == 'products':
                product = QueryBuilder.select(Product).where_eq("id", record_id).first()
                if product:
                    product.delete()
                    print(f"✅ Deleted product {record_id}: {product.name}")
                else:
                    print(f"❌ Product with ID {record_id} not found")
            
            else:
                print(f"❌ Unknown table: {table}")
        
        except Exception as e:
            print(f"❌ Error deleting record: {e}")
    
    def _display_users(self, users: List[User]):
        """Display users in a formatted table"""
        if not users:
            print("No users found.")
            return
        
        print(f"{'ID':<5} {'Name':<20} {'Email':<25} {'Age':<5} {'Balance':<10} {'Active':<8}")
        print("-" * 80)
        for user in users:
            print(f"{user.id:<5} {user.name:<20} {user.email:<25} {user.age or 'N/A':<5} ${user.balance:<9.2f} {user.is_active:<8}")
    
    def _display_products(self, products: List[Product]):
        """Display products in a formatted table"""
        if not products:
            print("No products found.")
            return
        
        print(f"{'ID':<5} {'Name':<20} {'Category':<15} {'Price':<10} {'In Stock':<10}")
        print("-" * 70)
        for product in products:
            print(f"{product.id:<5} {product.name:<20} {product.category or 'N/A':<15} ${product.price:<9.2f} {product.in_stock:<10}")
    
    def _show_stats(self):
        """Show database statistics"""
        try:
            user_count = QueryBuilder.select(User).count()
            active_user_count = QueryBuilder.select(User).where_eq("is_active", True).count()
            product_count = QueryBuilder.select(Product).count()
            in_stock_count = QueryBuilder.select(Product).where_eq("in_stock", True).count()
            
            print("\n📊 Database Statistics:")
            print(f"  👥 Users: {user_count} total, {active_user_count} active")
            print(f"  📦 Products: {product_count} total, {in_stock_count} in stock")
            
            # Average age and balance for users
            if user_count > 0:
                users = QueryBuilder.select(User).execute()
                ages = [u.age for u in users if u.age is not None]
                balances = [u.balance for u in users]
                
                if ages:
                    avg_age = sum(ages) / len(ages)
                    print(f"  📈 Average user age: {avg_age:.1f}")
                
                if balances:
                    avg_balance = sum(balances) / len(balances)
                    print(f"  💰 Average user balance: ${avg_balance:.2f}")
            
            # Average product price
            if product_count > 0:
                products = QueryBuilder.select(Product).execute()
                prices = [p.price for p in products]
                avg_price = sum(prices) / len(prices)
                print(f"  💵 Average product price: ${avg_price:.2f}")
        
        except Exception as e:
            print(f"❌ Error getting stats: {e}")
    
    def close(self):
        """Close database connection"""
        self.db.close()


def main():
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(description="Advanced Python Database CLI")
    parser.add_argument("--db", default="cli_database.db", help="Database file path")
    parser.add_argument("--command", help="Single command to execute")
    
    args = parser.parse_args()
    
    cli = DatabaseCLI(args.db)
    
    if args.command:
        # Execute single command
        cli._execute_command(args.command)
    else:
        # Run interactive mode
        cli.run_interactive()
    
    cli.close()


if __name__ == "__main__":
    main()

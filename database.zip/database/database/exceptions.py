"""
Custom exceptions for the database library
"""


class DatabaseError(Exception):
    """Base exception for all database-related errors"""
    pass


class ConnectionError(DatabaseError):
    """Raised when database connection fails"""
    pass


class ValidationError(DatabaseError):
    """Raised when data validation fails"""
    pass


class MigrationError(DatabaseError):
    """Raised when migration operations fail"""
    pass


class QueryError(DatabaseError):
    """Raised when query execution fails"""
    pass


class TransactionError(DatabaseError):
    """Raised when transaction operations fail"""
    pass

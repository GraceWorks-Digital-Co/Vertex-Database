"""
Query builder with fluent interface for advanced database operations
"""

import sqlite3
from typing import Any, Dict, List, Optional, Tuple, Union, TYPE_CHECKING
from abc import ABC, abstractmethod

from .exceptions import QueryError

if TYPE_CHECKING:
    from .models import Model


class Query(ABC):
    """Base query class"""
    
    def __init__(self, model_class: 'Model'):
        self.model_class = model_class
        self.database = model_class._database
        self.table_name = model_class._table_name
        self._where_clauses: List[str] = []
        self._params: List[Any] = []
        self._limit: Optional[int] = None
        self._offset: Optional[int] = None
        self._order_by: List[str] = []
    
    def where(self, condition: str, *params) -> 'Query':
        """Add WHERE clause"""
        self._where_clauses.append(condition)
        self._params.extend(params)
        return self
    
    def where_eq(self, field: str, value: Any) -> 'Query':
        """Add equality condition"""
        self._where_clauses.append(f"{field} = ?")
        self._params.append(value)
        return self
    
    def where_in(self, field: str, values: List[Any]) -> 'Query':
        """Add IN condition"""
        placeholders = ', '.join(['?' for _ in values])
        self._where_clauses.append(f"{field} IN ({placeholders})")
        self._params.extend(values)
        return self
    
    def where_like(self, field: str, pattern: str) -> 'Query':
        """Add LIKE condition"""
        self._where_clauses.append(f"{field} LIKE ?")
        self._params.append(pattern)
        return self
    
    def where_gt(self, field: str, value: Any) -> 'Query':
        """Add greater than condition"""
        self._where_clauses.append(f"{field} > ?")
        self._params.append(value)
        return self
    
    def where_gte(self, field: str, value: Any) -> 'Query':
        """Add greater than or equal condition"""
        self._where_clauses.append(f"{field} >= ?")
        self._params.append(value)
        return self
    
    def where_lt(self, field: str, value: Any) -> 'Query':
        """Add less than condition"""
        self._where_clauses.append(f"{field} < ?")
        self._params.append(value)
        return self
    
    def where_lte(self, field: str, value: Any) -> 'Query':
        """Add less than or equal condition"""
        self._where_clauses.append(f"{field} <= ?")
        self._params.append(value)
        return self
    
    def where_between(self, field: str, start: Any, end: Any) -> 'Query':
        """Add BETWEEN condition"""
        self._where_clauses.append(f"{field} BETWEEN ? AND ?")
        self._params.extend([start, end])
        return self
    
    def where_null(self, field: str) -> 'Query':
        """Add IS NULL condition"""
        self._where_clauses.append(f"{field} IS NULL")
        return self
    
    def where_not_null(self, field: str) -> 'Query':
        """Add IS NOT NULL condition"""
        self._where_clauses.append(f"{field} IS NOT NULL")
        return self
    
    def limit(self, count: int) -> 'Query':
        """Set LIMIT clause"""
        self._limit = count
        return self
    
    def offset(self, count: int) -> 'Query':
        """Set OFFSET clause"""
        self._offset = count
        return self
    
    def order_by(self, field: str, desc: bool = False) -> 'Query':
        """Add ORDER BY clause"""
        direction = "DESC" if desc else "ASC"
        self._order_by.append(f"{field} {direction}")
        return self
    
    def _build_where_clause(self) -> str:
        """Build WHERE clause from conditions"""
        if not self._where_clauses:
            return ""
        return "WHERE " + " AND ".join(self._where_clauses)
    
    def _build_order_by_clause(self) -> str:
        """Build ORDER BY clause"""
        if not self._order_by:
            return ""
        return "ORDER BY " + ", ".join(self._order_by)
    
    def _build_limit_clause(self) -> str:
        """Build LIMIT clause"""
        parts = []
        if self._limit is not None:
            parts.append(f"LIMIT {self._limit}")
        if self._offset is not None:
            parts.append(f"OFFSET {self._offset}")
        return " ".join(parts)
    
    @abstractmethod
    def execute(self) -> Any:
        """Execute the query"""
        pass


class SelectQuery(Query):
    """SELECT query builder"""
    
    def __init__(self, model_class: 'Model', fields: Optional[List[str]] = None):
        super().__init__(model_class)
        self._fields = fields or ['*']
    
    def select(self, *fields: str) -> 'SelectQuery':
        """Specify fields to select"""
        self._fields = list(fields)
        return self
    
    def count(self) -> int:
        """Count matching records"""
        if not self.database:
            raise QueryError("No database instance set")
        
        where_clause = self._build_where_clause()
        
        query = f"""
        SELECT COUNT(*) as count 
        FROM {self.table_name}
        {where_clause}
        """.strip()
        
        try:
            rows = self.database.execute(query, tuple(self._params))
            return rows[0]['count'] if rows else 0
        except sqlite3.Error as e:
            raise QueryError(f"COUNT query failed: {e}")
    
    def exists(self) -> bool:
        """Check if any records match the query"""
        return self.count() > 0
    
    def first(self) -> Optional['Model']:
        """Get first matching record"""
        self.limit(1)
        results = self.execute()
        return results[0] if results else None
    
    def execute(self) -> List['Model']:
        """Execute SELECT query and return model instances"""
        if not self.database:
            raise QueryError("No database instance set")
        
        fields_str = ', '.join(self._fields)
        where_clause = self._build_where_clause()
        order_by_clause = self._build_order_by_clause()
        limit_clause = self._build_limit_clause()
        
        query = f"""
        SELECT {fields_str} 
        FROM {self.table_name}
        {where_clause}
        {order_by_clause}
        {limit_clause}
        """.strip()
        
        try:
            rows = self.database.execute(query, tuple(self._params))
            return [self.model_class.from_row(row) for row in rows]
        except sqlite3.Error as e:
            raise QueryError(f"SELECT query failed: {e}")


class InsertQuery(Query):
    """INSERT query builder"""
    
    def __init__(self, model_class: 'Model'):
        super().__init__(model_class)
        self._data: Dict[str, Any] = {}
        self._batch_data: List[Dict[str, Any]] = []
    
    def values(self, **kwargs) -> 'InsertQuery':
        """Set values for single insert"""
        self._data.update(kwargs)
        return self
    
    def batch_values(self, data_list: List[Dict[str, Any]]) -> 'InsertQuery':
        """Set values for batch insert"""
        self._batch_data = data_list
        return self
    
    def execute(self) -> Optional[int]:
        """Execute INSERT query and return last row ID"""
        if not self.database:
            raise QueryError("No database instance set")
        
        if self._batch_data:
            return self._execute_batch()
        else:
            return self._execute_single()
    
    def _execute_single(self) -> Optional[int]:
        """Execute single INSERT"""
        if not self._data:
            raise QueryError("No data provided for insert")
        
        fields = list(self._data.keys())
        placeholders = ', '.join(['?' for _ in fields])
        values = list(self._data.values())
        
        query = f"""
        INSERT INTO {self.table_name} ({', '.join(fields)})
        VALUES ({placeholders})
        """
        
        try:
            with self.database.transaction() as conn:
                cursor = conn.execute(query, values)
                return cursor.lastrowid
        except sqlite3.Error as e:
            raise QueryError(f"INSERT query failed: {e}")
    
    def _execute_batch(self) -> None:
        """Execute batch INSERT"""
        if not self._batch_data:
            raise QueryError("No batch data provided for insert")
        
        fields = list(self._batch_data[0].keys())
        placeholders = ', '.join(['?' for _ in fields])
        values_list = [list(item.values()) for item in self._batch_data]
        
        query = f"""
        INSERT INTO {self.table_name} ({', '.join(fields)})
        VALUES ({placeholders})
        """
        
        try:
            self.database.execute_many(query, values_list)
        except sqlite3.Error as e:
            raise QueryError(f"Batch INSERT failed: {e}")


class UpdateQuery(Query):
    """UPDATE query builder"""
    
    def __init__(self, model_class: 'Model'):
        super().__init__(model_class)
        self._set_clauses: List[str] = []
        self._set_params: List[Any] = []
    
    def set(self, field: str, value: Any) -> 'UpdateQuery':
        """Add SET clause"""
        self._set_clauses.append(f"{field} = ?")
        self._set_params.append(value)
        return self
    
    def set_dict(self, data: Dict[str, Any]) -> 'UpdateQuery':
        """Add multiple SET clauses from dictionary"""
        for field, value in data.items():
            self.set(field, value)
        return self
    
    def execute(self) -> int:
        """Execute UPDATE query and return number of affected rows"""
        if not self.database:
            raise QueryError("No database instance set")
        
        if not self._set_clauses:
            raise QueryError("No SET clauses provided for update")
        
        where_clause = self._build_where_clause()
        set_clause = "SET " + ", ".join(self._set_clauses)
        
        query = f"""
        UPDATE {self.table_name}
        {set_clause}
        {where_clause}
        """.strip()
        
        all_params = self._set_params + self._params
        
        try:
            with self.database.transaction() as conn:
                cursor = conn.execute(query, tuple(all_params))
                return cursor.rowcount
        except sqlite3.Error as e:
            raise QueryError(f"UPDATE query failed: {e}")


class DeleteQuery(Query):
    """DELETE query builder"""
    
    def execute(self) -> int:
        """Execute DELETE query and return number of affected rows"""
        if not self.database:
            raise QueryError("No database instance set")
        
        where_clause = self._build_where_clause()
        
        query = f"""
        DELETE FROM {self.table_name}
        {where_clause}
        """.strip()
        
        try:
            with self.database.transaction() as conn:
                cursor = conn.execute(query, tuple(self._params))
                return cursor.rowcount
        except sqlite3.Error as e:
            raise QueryError(f"DELETE query failed: {e}")


class QueryBuilder:
    """Factory class for creating queries"""
    
    @staticmethod
    def select(model_class: 'Model', *fields: str) -> SelectQuery:
        """Create a SELECT query"""
        return SelectQuery(model_class, list(fields) if fields else None)
    
    @staticmethod
    def insert(model_class: 'Model') -> InsertQuery:
        """Create an INSERT query"""
        return InsertQuery(model_class)
    
    @staticmethod
    def update(model_class: 'Model') -> UpdateQuery:
        """Create an UPDATE query"""
        return UpdateQuery(model_class)
    
    @staticmethod
    def delete(model_class: 'Model') -> DeleteQuery:
        """Create a DELETE query"""
        return DeleteQuery(model_class)

"""
Indexing system for the database library
Provides secondary indexing for faster queries
"""

import json
import os
from typing import Dict, List, Any, Optional, Set
from collections import defaultdict
from pathlib import Path

from .exceptions import DatabaseError


class Index:
    """Base index class for secondary indexing"""
    
    def __init__(self, index_name: str, field_name: str, index_dir: str = "indexes"):
        self.index_name = index_name
        self.field_name = field_name
        self.index_dir = Path(index_dir)
        self.index_dir.mkdir(exist_ok=True)
        self.index_file = self.index_dir / f"{index_name}.json"
        self._index: Dict[Any, Set[int]] = defaultdict(set)
        self._dirty = False
        self._load_index()
    
    def _load_index(self):
        """Load index from disk"""
        if self.index_file.exists():
            try:
                with open(self.index_file, 'r') as f:
                    data = json.load(f)
                    # Convert lists back to sets
                    self._index = defaultdict(set, {k: set(v) for k, v in data.items()})
                self._dirty = False
            except (json.JSONDecodeError, IOError) as e:
                raise DatabaseError(f"Failed to load index {self.index_name}: {e}")
    
    def _save_index(self):
        """Save index to disk"""
        if not self._dirty:
            return
        
        try:
            # Convert sets to lists for JSON serialization
            data = {k: list(v) for k, v in self._index.items()}
            with open(self.index_file, 'w') as f:
                json.dump(data, f, indent=2)
            self._dirty = False
        except IOError as e:
            raise DatabaseError(f"Failed to save index {self.index_name}: {e}")
    
    def add(self, key: Any, record_id: int):
        """Add a record to the index"""
        self._index[key].add(record_id)
        self._dirty = True
    
    def remove(self, key: Any, record_id: int):
        """Remove a record from the index"""
        if key in self._index:
            self._index[key].discard(record_id)
            if not self._index[key]:
                del self._index[key]
            self._dirty = True
    
    def update(self, old_key: Any, new_key: Any, record_id: int):
        """Update a record in the index"""
        self.remove(old_key, record_id)
        self.add(new_key, record_id)
    
    def find(self, key: Any) -> Set[int]:
        """Find record IDs by key"""
        return self._index.get(key, set())
    
    def find_range(self, min_key: Any, max_key: Any) -> Set[int]:
        """Find record IDs in a range (for numeric indexes)"""
        result = set()
        for key, ids in self._index.items():
            if isinstance(key, (int, float)) and min_key <= key <= max_key:
                result.update(ids)
        return result
    
    def all_keys(self) -> List[Any]:
        """Get all indexed keys"""
        return list(self._index.keys())
    
    def size(self) -> int:
        """Get the number of indexed keys"""
        return len(self._index)
    
    def save(self):
        """Force save the index"""
        self._save_index()
    
    def rebuild(self, model_class):
        """Rebuild the index from scratch"""
        self._index.clear()
        self._dirty = True
        
        # This would need to be implemented with model class access
        # For now, just clear the index
        self._save_index()


class IndexManager:
    """Manages multiple indexes for a database"""
    
    def __init__(self, index_dir: str = "indexes"):
        self.index_dir = Path(index_dir)
        self.index_dir.mkdir(exist_ok=True)
        self._indexes: Dict[str, Index] = {}
        self._load_existing_indexes()
    
    def _load_existing_indexes(self):
        """Load existing indexes from disk"""
        for index_file in self.index_dir.glob("*.json"):
            index_name = index_file.stem
            # Extract field name from index name (format: tablename_fieldname)
            if "_" in index_name:
                table_name, field_name = index_name.split("_", 1)
                self._indexes[index_name] = Index(index_name, field_name, str(self.index_dir))
    
    def create_index(self, table_name: str, field_name: str) -> Index:
        """Create a new index"""
        index_name = f"{table_name}_{field_name}"
        if index_name in self._indexes:
            return self._indexes[index_name]
        
        index = Index(index_name, field_name, str(self.index_dir))
        self._indexes[index_name] = index
        return index
    
    def get_index(self, table_name: str, field_name: str) -> Optional[Index]:
        """Get an existing index"""
        index_name = f"{table_name}_{field_name}"
        return self._indexes.get(index_name)
    
    def drop_index(self, table_name: str, field_name: str):
        """Drop an index"""
        index_name = f"{table_name}_{field_name}"
        if index_name in self._indexes:
            index_file = self.index_dir / f"{index_name}.json"
            if index_file.exists():
                index_file.unlink()
            del self._indexes[index_name]
    
    def list_indexes(self) -> List[str]:
        """List all index names"""
        return list(self._indexes.keys())
    
    def save_all(self):
        """Save all indexes"""
        for index in self._indexes.values():
            index.save()
    
    def get_stats(self) -> Dict[str, Any]:
        """Get index statistics"""
        stats = {
            "total_indexes": len(self._indexes),
            "indexes": {}
        }
        
        for name, index in self._indexes.items():
            stats["indexes"][name] = {
                "field": index.field_name,
                "keys": index.size(),
                "file_size": index.index_file.stat().st_size if index.index_file.exists() else 0
            }
        
        return stats

"""
Core database functionality including connection management and basic operations
"""

import sqlite3
import threading
import time
from contextlib import contextmanager
from typing import Optional, Dict, Any, List, Union
from pathlib import Path

from .exceptions import ConnectionError, TransactionError, QueryError
from .indexing import IndexManager
from .transactions import TransactionManager


class ConnectionPool:
    """Thread-safe connection pool for SQLite database"""
    
    def __init__(self, database_path: str, max_connections: int = 10):
        self.database_path = database_path
        self.max_connections = max_connections
        self._pool = []
        self._lock = threading.Lock()
        self._created_connections = 0
        
    def get_connection(self) -> sqlite3.Connection:
        """Get a connection from the pool"""
        with self._lock:
            if self._pool:
                return self._pool.pop()
            
            if self._created_connections < self.max_connections:
                conn = self._create_connection()
                self._created_connections += 1
                return conn
            
            raise ConnectionError("Connection pool exhausted")
    
    def return_connection(self, connection: sqlite3.Connection):
        """Return a connection to the pool"""
        with self._lock:
            if len(self._pool) < self.max_connections:
                try:
                    connection.rollback()
                    self._pool.append(connection)
                except sqlite3.Error:
                    pass
    
    def _create_connection(self) -> sqlite3.Connection:
        """Create a new database connection"""
        try:
            conn = sqlite3.connect(
                self.database_path,
                check_same_thread=False,
                timeout=30.0
            )
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA foreign_keys=ON")
            conn.execute("PRAGMA journal_mode=WAL")
            return conn
        except sqlite3.Error as e:
            raise ConnectionError(f"Failed to create connection: {e}")
    
    def close_all(self):
        """Close all connections in the pool"""
        with self._lock:
            while self._pool:
                conn = self._pool.pop()
                try:
                    conn.close()
                except sqlite3.Error:
                    pass
            self._created_connections = 0


class Database:
    """Main database class with connection pooling and transaction management"""
    
    def __init__(self, database_path: str = ":memory:", pool_size: int = 10):
        self.database_path = database_path
        self.pool = ConnectionPool(database_path, pool_size)
        self._local = threading.local()
        
        # Initialize enhanced features
        self.index_manager = IndexManager(f"{database_path}_indexes" if database_path != ":memory:" else ":memory_indexes")
        self.transaction_manager = TransactionManager()
        
        if database_path != ":memory:":
            Path(database_path).parent.mkdir(parents=True, exist_ok=True)
    
    @contextmanager
    def get_connection(self):
        """Context manager for getting a connection from the pool"""
        conn = self.pool.get_connection()
        try:
            yield conn
        finally:
            self.pool.return_connection(conn)
    
    @contextmanager
    def transaction(self):
        """Context manager for database transactions"""
        with self.get_connection() as conn:
            try:
                conn.execute("BEGIN")
                # Set transaction flag for nested operations
                self._local.in_transaction = True
                self._local.connection = conn
                yield conn
                conn.commit()
            except Exception as e:
                try:
                    conn.rollback()
                except sqlite3.Error:
                    pass
                raise TransactionError(f"Transaction failed: {e}")
            finally:
                # Clear transaction flag
                self._local.in_transaction = False
                self._local.connection = None
    
    def execute(self, query: str, params: tuple = ()) -> List[sqlite3.Row]:
        """Execute a query and return results"""
        with self.get_connection() as conn:
            try:
                cursor = conn.execute(query, params)
                # Check if this is a modifying query (INSERT, UPDATE, DELETE)
                query_upper = query.upper().strip()
                if any(query_upper.startswith(prefix) for prefix in ['INSERT', 'UPDATE', 'DELETE', 'CREATE', 'DROP', 'ALTER']):
                    conn.commit()
                    return cursor.fetchall() if cursor.description else []
                else:
                    return cursor.fetchall()
            except sqlite3.Error as e:
                raise QueryError(f"Query execution failed: {e}")
    
    def execute_many(self, query: str, params_list: List[tuple]) -> None:
        """Execute a query multiple times with different parameters"""
        with self.get_connection() as conn:
            try:
                conn.executemany(query, params_list)
                conn.commit()
            except sqlite3.Error as e:
                raise QueryError(f"Batch execution failed: {e}")
    
    def execute_script(self, script: str) -> None:
        """Execute a SQL script"""
        with self.get_connection() as conn:
            try:
                conn.executescript(script)
                conn.commit()
            except sqlite3.Error as e:
                raise QueryError(f"Script execution failed: {e}")
    
    def table_exists(self, table_name: str) -> bool:
        """Check if a table exists"""
        query = """
        SELECT name FROM sqlite_master 
        WHERE type='table' AND name=?
        """
        result = self.execute(query, (table_name,))
        return len(result) > 0
    
    def get_table_info(self, table_name: str) -> List[sqlite3.Row]:
        """Get table schema information"""
        query = f"PRAGMA table_info({table_name})"
        return self.execute(query)
    
    # Enhanced transaction methods
    def begin_transaction(self) -> str:
        """Begin a new transaction and return its ID"""
        conn = self.pool.get_connection()
        try:
            transaction = self.transaction_manager.begin_transaction(conn)
            return transaction.transaction_id
        except Exception:
            self.pool.return_connection(conn)
            raise
    
    def commit_transaction(self, transaction_id: str):
        """Commit a transaction by ID"""
        transaction = self.transaction_manager.get_transaction(transaction_id)
        if not transaction:
            raise TransactionError(f"Transaction {transaction_id} not found")
        
        try:
            self.transaction_manager.commit_transaction(transaction_id)
        finally:
            self.pool.return_connection(transaction.connection)
    
    def rollback_transaction(self, transaction_id: str):
        """Rollback a transaction by ID"""
        transaction = self.transaction_manager.get_transaction(transaction_id)
        if not transaction:
            raise TransactionError(f"Transaction {transaction_id} not found")
        
        try:
            self.transaction_manager.rollback_transaction(transaction_id)
        finally:
            self.pool.return_connection(transaction.connection)
    
    def get_transaction(self, transaction_id: str):
        """Get a transaction object by ID"""
        return self.transaction_manager.get_transaction(transaction_id)
    
    def list_active_transactions(self) -> List[str]:
        """List all active transaction IDs"""
        return self.transaction_manager.list_active_transactions()
    
    def get_transaction_stats(self) -> dict:
        """Get statistics about active transactions"""
        return self.transaction_manager.get_transaction_stats()
    
    # Index management methods
    def create_index(self, table_name: str, field_name: str):
        """Create a secondary index on a field"""
        return self.index_manager.create_index(table_name, field_name)
    
    def get_index(self, table_name: str, field_name: str):
        """Get an existing index"""
        return self.index_manager.get_index(table_name, field_name)
    
    def drop_index(self, table_name: str, field_name: str):
        """Drop a secondary index"""
        self.index_manager.drop_index(table_name, field_name)
    
    def list_indexes(self) -> List[str]:
        """List all indexes"""
        return self.index_manager.list_indexes()
    
    def get_index_stats(self) -> dict:
        """Get index statistics"""
        return self.index_manager.get_stats()
    
    def save_indexes(self):
        """Save all indexes to disk"""
        self.index_manager.save_all()
    
    def close(self):
        """Close the database and all connections"""
        self.transaction_manager.cleanup()
        self.index_manager.save_all()
        self.pool.close_all()
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

"""
ORM-like model definitions with field types and validation
"""

import sqlite3
from datetime import datetime
from typing import Any, Dict, List, Optional, Type, Union, get_type_hints
from dataclasses import dataclass, field

from .exceptions import ValidationError
from .core import Database


@dataclass
class Field:
    """Base field class for model definitions"""
    name: str = ""
    nullable: bool = True
    primary_key: bool = False
    unique: bool = False
    default: Any = None
    index: bool = False
    
    def __post_init__(self):
        pass
    
    def to_sql_type(self) -> str:
        """Convert field to SQLite type definition"""
        raise NotImplementedError
    
    def validate(self, value: Any) -> Any:
        """Validate field value"""
        if value is None and not self.nullable:
            raise ValidationError(f"Field '{self.name}' cannot be null")
        return value
    
    def get_default(self) -> Any:
        """Get default value for field"""
        if callable(self.default):
            return self.default()
        return self.default


class StringField(Field):
    def __init__(self, max_length: int = 255, **kwargs):
        self.max_length = max_length
        super().__init__(**kwargs)
    
    def to_sql_type(self) -> str:
        null_constraint = "NOT NULL" if not self.nullable else ""
        pk_constraint = "PRIMARY KEY" if self.primary_key else ""
        unique_constraint = "UNIQUE" if self.unique else ""
        
        constraints = [c for c in [null_constraint, pk_constraint, unique_constraint] if c]
        return f"VARCHAR({self.max_length}) {' '.join(constraints)}"
    
    def validate(self, value: Any) -> str:
        if value is None and self.nullable:
            return None
        
        if not isinstance(value, str):
            value = str(value)
        
        if len(value) > self.max_length:
            raise ValidationError(f"String value too long for field '{self.name}'")
        
        return super().validate(value)


class IntegerField(Field):
    def to_sql_type(self) -> str:
        null_constraint = "NOT NULL" if not self.nullable else ""
        pk_constraint = "PRIMARY KEY" if self.primary_key else ""
        unique_constraint = "UNIQUE" if self.unique else ""
        
        constraints = [c for c in [null_constraint, pk_constraint, unique_constraint] if c]
        return f"INTEGER {' '.join(constraints)}"
    
    def validate(self, value: Any) -> int:
        if value is None and self.nullable:
            return None
        
        try:
            return int(value)
        except (ValueError, TypeError):
            raise ValidationError(f"Invalid integer value for field '{self.name}'")


class FloatField(Field):
    def to_sql_type(self) -> str:
        null_constraint = "NOT NULL" if not self.nullable else ""
        unique_constraint = "UNIQUE" if self.unique else ""
        
        constraints = [c for c in [null_constraint, unique_constraint] if c]
        return f"REAL {' '.join(constraints)}"
    
    def validate(self, value: Any) -> float:
        if value is None and self.nullable:
            return None
        
        try:
            return float(value)
        except (ValueError, TypeError):
            raise ValidationError(f"Invalid float value for field '{self.name}'")


class BooleanField(Field):
    def to_sql_type(self) -> str:
        null_constraint = "NOT NULL" if not self.nullable else ""
        
        constraints = [c for c in [null_constraint] if c]
        return f"BOOLEAN {' '.join(constraints)}"
    
    def validate(self, value: Any) -> bool:
        if value is None and self.nullable:
            return None
        
        if isinstance(value, bool):
            return value
        
        if isinstance(value, (int, float)):
            return bool(value)
        
        if isinstance(value, str):
            return value.lower() in ('true', '1', 'yes', 'on')
        
        raise ValidationError(f"Invalid boolean value for field '{self.name}'")


class DateTimeField(Field):
    def to_sql_type(self) -> str:
        null_constraint = "NOT NULL" if not self.nullable else ""
        
        constraints = [c for c in [null_constraint] if c]
        return f"DATETIME {' '.join(constraints)}"
    
    def validate(self, value: Any) -> str:
        if value is None and self.nullable:
            return None
        
        if isinstance(value, datetime):
            return value.isoformat()
        
        if isinstance(value, str):
            try:
                datetime.fromisoformat(value)
                return value
            except ValueError:
                raise ValidationError(f"Invalid datetime format for field '{self.name}'")
        
        raise ValidationError(f"Invalid datetime value for field '{self.name}'")


class ModelMeta(type):
    """Metaclass for Model to collect field definitions"""
    
    def __new__(mcs, name: str, bases: tuple, namespace: dict):
        fields = {}
        
        for base in bases:
            if hasattr(base, '_fields'):
                fields.update(base._fields)
        
        for key, value in list(namespace.items()):
            if isinstance(value, Field):
                value.name = key
                fields[key] = value
                # Remove the field object from the class namespace
                del namespace[key]
        
        namespace['_fields'] = fields
        namespace['_table_name'] = namespace.get('table_name', name.lower())
        
        return super().__new__(mcs, name, bases, namespace)


class Model(metaclass=ModelMeta):
    """Base model class with ORM-like functionality"""
    
    _database: Optional[Database] = None
    _fields: Dict[str, Field] = {}
    _table_name: str = ""
    
    def __init__(self, **kwargs):
        self._data = {}
        self._dirty = set()
        
        for field_name, field_obj in self._fields.items():
            if field_name in kwargs:
                value = field_obj.validate(kwargs[field_name])
                self._data[field_name] = value
            elif field_obj.default is not None:
                self._data[field_name] = field_obj.get_default()
            elif field_obj.primary_key:
                # Primary key fields can be auto-generated
                pass
            elif not field_obj.nullable:
                raise ValidationError(f"Required field '{field_name}' not provided")
    
    def __getattr__(self, name: str) -> Any:
        if name in self._fields:
            return self._data.get(name)
        raise AttributeError(f"'{self.__class__.__name__}' has no attribute '{name}'")
    
    def __setattr__(self, name: str, value: Any):
        if name.startswith('_') or name not in self._fields:
            super().__setattr__(name, value)
        else:
            field_obj = self._fields[name]
            validated_value = field_obj.validate(value)
            self._data[name] = validated_value
            self._dirty.add(name)
    
    @classmethod
    def set_database(cls, database: Database):
        """Set the database instance for all models"""
        cls._database = database
    
    @classmethod
    def create_table(cls) -> None:
        """Create the table for this model"""
        if not cls._database:
            raise ValidationError("No database instance set")
        
        columns = []
        for field_name, field_obj in cls._fields.items():
            column_def = f"{field_name} {field_obj.to_sql_type()}"
            columns.append(column_def)
        
        create_sql = f"""
        CREATE TABLE IF NOT EXISTS {cls._table_name} (
            {', '.join(columns)}
        )
        """
        
        cls._database.execute(create_sql)
        
        for field_name, field_obj in cls._fields.items():
            if field_obj.index and not field_obj.primary_key:
                index_sql = f"""
                CREATE INDEX IF NOT EXISTS idx_{cls._table_name}_{field_name} 
                ON {cls._table_name} ({field_name})
                """
                cls._database.execute(index_sql)
    
    @classmethod
    def drop_table(cls) -> None:
        """Drop the table for this model"""
        if not cls._database:
            raise ValidationError("No database instance set")
        
        cls._database.execute(f"DROP TABLE IF EXISTS {cls._table_name}")
    
    def save(self) -> None:
        """Save the model instance to the database"""
        if not self._database:
            raise ValidationError("No database instance set")
        
        primary_key_fields = [name for name, field in self._fields.items() if field.primary_key]
        
        if primary_key_fields:
            pk_field = primary_key_fields[0]
            pk_value = getattr(self, pk_field, None)
            
            if pk_value is not None:
                self._update()
            else:
                self._insert()
        else:
            self._insert()
    
    def _insert(self) -> None:
        """Insert a new record"""
        field_names = list(self._fields.keys())
        placeholders = ', '.join(['?' for _ in field_names])
        values = [getattr(self, name) for name in field_names]
        
        insert_sql = f"INSERT INTO {self._table_name} ({', '.join(field_names)}) VALUES ({placeholders})"
        
        # Check if we're already in a transaction
        if (hasattr(self._database._local, 'in_transaction') and 
            self._database._local.in_transaction and 
            hasattr(self._database._local, 'connection')):
            # Use existing connection
            conn = self._database._local.connection
            cursor = conn.execute(insert_sql, values)
            
            primary_key_fields = [name for name, field in self._fields.items() if field.primary_key]
            if primary_key_fields:
                pk_field = primary_key_fields[0]
                if getattr(self, pk_field) is None:
                    setattr(self, pk_field, cursor.lastrowid)
        else:
            # Create new transaction
            with self._database.transaction() as conn:
                cursor = conn.execute(insert_sql, values)
                
                primary_key_fields = [name for name, field in self._fields.items() if field.primary_key]
                if primary_key_fields:
                    pk_field = primary_key_fields[0]
                    if getattr(self, pk_field) is None:
                        setattr(self, pk_field, cursor.lastrowid)
        
        self._dirty.clear()
    
    def _update(self) -> None:
        """Update an existing record"""
        primary_key_fields = [name for name, field in self._fields.items() if field.primary_key]
        if not primary_key_fields:
            raise ValidationError("Cannot update model without primary key")
        
        pk_field = primary_key_fields[0]
        pk_value = getattr(self, pk_field)
        
        if not self._dirty:
            return
        
        set_clauses = []
        values = []
        
        for field_name in self._dirty:
            if field_name != pk_field:
                set_clauses.append(f"{field_name} = ?")
                values.append(getattr(self, field_name))
        
        if not set_clauses:
            return
        
        values.append(pk_value)
        update_sql = f"UPDATE {self._table_name} SET {', '.join(set_clauses)} WHERE {pk_field} = ?"
        
        self._database.execute(update_sql, tuple(values))
        self._dirty.clear()
    
    def delete(self) -> None:
        """Delete the model instance from the database"""
        if not self._database:
            raise ValidationError("No database instance set")
        
        primary_key_fields = [name for name, field in self._fields.items() if field.primary_key]
        if not primary_key_fields:
            raise ValidationError("Cannot delete model without primary key")
        
        pk_field = primary_key_fields[0]
        pk_value = getattr(self, pk_field)
        
        if pk_value is None:
            raise ValidationError("Cannot delete unsaved model")
        
        delete_sql = f"DELETE FROM {self._table_name} WHERE {pk_field} = ?"
        self._database.execute(delete_sql, (pk_value,))
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert model instance to dictionary"""
        result = {}
        for name in self._fields.keys():
            value = self._data.get(name)
            if value is not None:
                result[name] = value
        return result
    
    @classmethod
    def from_row(cls, row: sqlite3.Row) -> 'Model':
        """Create model instance from database row"""
        data = dict(row)
        # Create instance without going through __init__ validation
        instance = cls.__new__(cls)
        instance._data = {}
        instance._dirty = set()
        
        for field_name, field_obj in cls._fields.items():
            if field_name in data:
                value = field_obj.validate(data[field_name])
                instance._data[field_name] = value
        
        return instance
    
    def __repr__(self) -> str:
        class_name = self.__class__.__name__
        fields_str = ', '.join(f"{k}={v!r}" for k, v in self.to_dict().items())
        return f"{class_name}({fields_str})"

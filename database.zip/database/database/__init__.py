"""
Advanced Python Database Library
Features:
- SQLite backend with connection pooling
- ORM-like model definitions
- Query builder with fluent interface
- Enhanced transaction management with explicit control
- Secondary indexing for faster queries
- Persistent indexes and transaction logs
"""

from .core import Database, ConnectionPool
from .models import Model, Field, StringField, IntegerField, FloatField, BooleanField, DateTimeField
from .query import Query, SelectQuery, InsertQuery, UpdateQuery, DeleteQuery, QueryBuilder
from .exceptions import DatabaseError, ValidationError, MigrationError, TransactionError, QueryError
from .indexing import Index, IndexManager
from .transactions import Transaction, TransactionManager, TransactionState, TransactionLog

__version__ = "2.0.0"
__all__ = [
    "Database", "ConnectionPool",
    "Model", "Field", "StringField", "IntegerField", "FloatField", 
    "BooleanField", "DateTimeField",
    "Query", "SelectQuery", "InsertQuery", "UpdateQuery", "DeleteQuery", "QueryBuilder",
    "DatabaseError", "ValidationError", "MigrationError", "TransactionError", "QueryError",
    "Index", "IndexManager", "Transaction", "TransactionManager", "TransactionState", "TransactionLog"
]

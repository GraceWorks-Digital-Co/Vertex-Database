"""
Enhanced transaction management with explicit control
"""

import sqlite3
import threading
import time
from contextlib import contextmanager
from typing import Optional, List, Any
from dataclasses import dataclass
from enum import Enum

from .exceptions import TransactionError


class TransactionState(Enum):
    """Transaction states"""
    INACTIVE = "inactive"
    ACTIVE = "active"
    COMMITTED = "committed"
    ROLLED_BACK = "rolled_back"


@dataclass
class TransactionLog:
    """Transaction log entry"""
    timestamp: float
    operation: str
    table: str
    record_id: Optional[int]
    old_data: Optional[dict]
    new_data: Optional[dict]


class Transaction:
    """Explicit transaction with logging"""
    
    def __init__(self, connection: sqlite3.Connection, transaction_id: str):
        self.connection = connection
        self.transaction_id = transaction_id
        self.state = TransactionState.INACTIVE
        self.start_time = None
        self.log: List[TransactionLog] = []
        self.savepoints: List[str] = []
    
    def begin(self):
        """Begin the transaction"""
        if self.state != TransactionState.INACTIVE:
            raise TransactionError(f"Transaction already {self.state.value}")
        
        self.connection.execute("BEGIN")
        self.state = TransactionState.ACTIVE
        self.start_time = time.time()
        self._log("BEGIN", None, None, None)
    
    def commit(self):
        """Commit the transaction"""
        if self.state != TransactionState.ACTIVE:
            raise TransactionError(f"Cannot commit transaction in {self.state.value} state")
        
        self.connection.commit()
        self.state = TransactionState.COMMITTED
        self._log("COMMIT", None, None, None)
    
    def rollback(self):
        """Rollback the transaction"""
        if self.state == TransactionState.INACTIVE:
            raise TransactionError("No transaction to rollback")
        
        if self.state == TransactionState.ACTIVE:
            self.connection.rollback()
        
        self.state = TransactionState.ROLLED_BACK
        self._log("ROLLBACK", None, None, None)
    
    def savepoint(self, name: str = None):
        """Create a savepoint"""
        if self.state != TransactionState.ACTIVE:
            raise TransactionError("Cannot create savepoint outside active transaction")
        
        if name is None:
            name = f"sp_{len(self.savepoints)}"
        
        self.connection.execute(f"SAVEPOINT {name}")
        self.savepoints.append(name)
        self._log("SAVEPOINT", None, None, {"name": name})
        return name
    
    def rollback_to_savepoint(self, name: str):
        """Rollback to a savepoint"""
        if self.state != TransactionState.ACTIVE:
            raise TransactionError("Cannot rollback to savepoint outside active transaction")
        
        if name not in self.savepoints:
            raise TransactionError(f"Savepoint {name} not found")
        
        self.connection.execute(f"ROLLBACK TO SAVEPOINT {name}")
        # Remove savepoints created after this one
        index = self.savepoints.index(name)
        self.savepoints = self.savepoints[:index + 1]
        self._log("ROLLBACK_TO_SAVEPOINT", None, None, {"name": name})
    
    def release_savepoint(self, name: str):
        """Release a savepoint"""
        if self.state != TransactionState.ACTIVE:
            raise TransactionError("Cannot release savepoint outside active transaction")
        
        if name not in self.savepoints:
            raise TransactionError(f"Savepoint {name} not found")
        
        self.connection.execute(f"RELEASE SAVEPOINT {name}")
        self.savepoints.remove(name)
        self._log("RELEASE_SAVEPOINT", None, None, {"name": name})
    
    def _log(self, operation: str, table: str, record_id: Optional[int], data: Optional[dict]):
        """Log a transaction operation"""
        log_entry = TransactionLog(
            timestamp=time.time(),
            operation=operation,
            table=table,
            record_id=record_id,
            old_data=data.get("old") if data else None,
            new_data=data.get("new") if data else None
        )
        self.log.append(log_entry)
    
    def log_operation(self, operation: str, table: str, record_id: Optional[int], 
                     old_data: Optional[dict] = None, new_data: Optional[dict] = None):
        """Log a database operation"""
        if self.state == TransactionState.ACTIVE:
            self._log(operation, table, record_id, {"old": old_data, "new": new_data})
    
    def get_duration(self) -> Optional[float]:
        """Get transaction duration in seconds"""
        if self.start_time:
            return time.time() - self.start_time
        return None
    
    def get_log_summary(self) -> dict:
        """Get a summary of the transaction log"""
        operations = {}
        for entry in self.log:
            operations[entry.operation] = operations.get(entry.operation, 0) + 1
        
        return {
            "transaction_id": self.transaction_id,
            "state": self.state.value,
            "duration": self.get_duration(),
            "operations": operations,
            "total_operations": len(self.log),
            "savepoints": len(self.savepoints)
        }


class TransactionManager:
    """Manages multiple transactions"""
    
    def __init__(self):
        self._transactions: Dict[str, Transaction] = {}
        self._lock = threading.Lock()
        self._counter = 0
    
    def begin_transaction(self, connection: sqlite3.Connection) -> Transaction:
        """Begin a new transaction"""
        with self._lock:
            self._counter += 1
            transaction_id = f"tx_{self._counter}_{int(time.time() * 1000)}"
            
            transaction = Transaction(connection, transaction_id)
            transaction.begin()
            self._transactions[transaction_id] = transaction
            
            return transaction
    
    def get_transaction(self, transaction_id: str) -> Optional[Transaction]:
        """Get an existing transaction"""
        return self._transactions.get(transaction_id)
    
    def commit_transaction(self, transaction_id: str):
        """Commit a transaction"""
        transaction = self._transactions.get(transaction_id)
        if not transaction:
            raise TransactionError(f"Transaction {transaction_id} not found")
        
        transaction.commit()
        del self._transactions[transaction_id]
    
    def rollback_transaction(self, transaction_id: str):
        """Rollback a transaction"""
        transaction = self._transactions.get(transaction_id)
        if not transaction:
            raise TransactionError(f"Transaction {transaction_id} not found")
        
        transaction.rollback()
        del self._transactions[transaction_id]
    
    def list_active_transactions(self) -> List[str]:
        """List all active transaction IDs"""
        return list(self._transactions.keys())
    
    def get_transaction_stats(self) -> dict:
        """Get statistics about active transactions"""
        stats = {
            "active_transactions": len(self._transactions),
            "transactions": {}
        }
        
        for tx_id, transaction in self._transactions.items():
            stats["transactions"][tx_id] = transaction.get_log_summary()
        
        return stats
    
    def cleanup(self):
        """Rollback all active transactions"""
        with self._lock:
            for transaction_id in list(self._transactions.keys()):
                try:
                    self.rollback_transaction(transaction_id)
                except TransactionError:
                    pass  # Already rolled back or committed

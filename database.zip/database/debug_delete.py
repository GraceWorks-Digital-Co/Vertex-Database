"""
Debug delete functionality
"""

from database import Database, Model, StringField, IntegerField
from database.query import QueryBuilder


class TestModel(Model):
    table_name = "test_models"
    
    id = IntegerField(primary_key=True, nullable=False)
    name = StringField(max_length=50, nullable=False)
    value = IntegerField(default=0)


def main():
    db = Database("debug_delete.db")
    Model.set_database(db)
    TestModel.create_table()
    
    # Create a model
    model = TestModel(name="test_delete", value=25)
    model.save()
    print(f"Created model: {model}")
    print(f"Model ID: {model.id}")
    
    # Check it exists
    before = QueryBuilder.select(TestModel).where_eq("id", model.id).first()
    print(f"Before delete: {before}")
    
    # Delete it
    model.delete()
    print("Deleted model")
    
    # Check it's gone
    after = QueryBuilder.select(TestModel).where_eq("id", model.id).first()
    print(f"After delete: {after}")
    
    # Check all records
    all_records = QueryBuilder.select(TestModel).execute()
    print(f"All records: {len(all_records)}")
    for record in all_records:
        print(f"  {record}")
    
    db.close()


if __name__ == "__main__":
    main()

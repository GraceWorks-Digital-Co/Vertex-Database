#!/usr/bin/env python3
"""
Task Automation System
A real-world application using the Advanced Python Database Library
Features task scheduling, status tracking, and execution logging
"""

import json
import time
import subprocess
import threading
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from enum import Enum

from database import (
    Database, Model, StringField, IntegerField, FloatField, 
    BooleanField, DateTimeField, QueryBuilder, IndexManager
)
from database.transactions import TransactionManager


class TaskStatus(Enum):
    """Task execution status"""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class TaskPriority(Enum):
    """Task priority levels"""
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    CRITICAL = 4


class Task(Model):
    """Task model for automation system"""
    table_name = "tasks"
    
    id = IntegerField(primary_key=True, nullable=False)
    name = StringField(max_length=200, nullable=False)
    description = StringField(max_length=500)
    command = StringField(max_length=1000, nullable=False)
    status = StringField(max_length=20, default=TaskStatus.PENDING.value)
    priority = IntegerField(default=TaskPriority.MEDIUM.value)
    scheduled_at = DateTimeField(nullable=True)
    started_at = DateTimeField(nullable=True)
    completed_at = DateTimeField(nullable=True)
    timeout_seconds = IntegerField(default=300)
    retry_count = IntegerField(default=0)
    max_retries = IntegerField(default=3)
    created_at = DateTimeField(default=datetime.now)
    updated_at = DateTimeField(default=datetime.now)


class TaskExecution(Model):
    """Task execution log"""
    table_name = "task_executions"
    
    id = IntegerField(primary_key=True, nullable=False)
    task_id = IntegerField(nullable=False)
    execution_id = StringField(max_length=50, nullable=False)
    status = StringField(max_length=20, nullable=False)
    started_at = DateTimeField(default=datetime.now)
    completed_at = DateTimeField(nullable=True)
    exit_code = IntegerField(nullable=True)
    stdout = StringField(max_length=5000)
    stderr = StringField(max_length=5000)
    duration_seconds = FloatField(nullable=True)
    worker_id = StringField(max_length=50)


class TaskDependency(Model):
    """Task dependencies"""
    table_name = "task_dependencies"
    
    id = IntegerField(primary_key=True, nullable=False)
    task_id = IntegerField(nullable=False)
    depends_on_task_id = IntegerField(nullable=False)
    created_at = DateTimeField(default=datetime.now)


class TaskAutomationSystem:
    """Main task automation system"""
    
    def __init__(self, db_path: str = "task_automation.db"):
        self.db = Database(db_path)
        Model.set_database(self.db)
        self.worker_id = f"worker_{int(time.time())}"
        self.running = False
        self.worker_thread = None
        self._init_database()
    
    def _init_database(self):
        """Initialize database tables and indexes"""
        # Create tables
        Task.create_table()
        TaskExecution.create_table()
        TaskDependency.create_table()
        
        # Create indexes for performance
        self.db.create_index("tasks", "status")
        self.db.create_index("tasks", "priority")
        self.db.create_index("tasks", "scheduled_at")
        self.db.create_index("task_executions", "task_id")
        self.db.create_index("task_executions", "status")
        self.db.create_index("task_dependencies", "task_id")
    
    def add_task(self, name: str, command: str, description: str = "", 
                 priority: TaskPriority = TaskPriority.MEDIUM,
                 scheduled_at: Optional[datetime] = None,
                 max_retries: int = 3,
                 timeout_seconds: int = 300,
                 dependencies: List[int] = None) -> int:
        """Add a new task to the system"""
        
        # Validate dependencies exist
        if dependencies:
            for dep_id in dependencies:
                if not QueryBuilder.select(Task).where_eq("id", dep_id).first():
                    raise ValueError(f"Dependency task {dep_id} not found")
        
        task = Task(
            name=name,
            description=description,
            command=command,
            priority=priority.value,
            scheduled_at=scheduled_at,
            max_retries=max_retries,
            timeout_seconds=timeout_seconds,
            status=TaskStatus.PENDING.value
        )
        task.save()
        
        # Add dependencies
        if dependencies:
            tx_id = self.db.begin_transaction()
            try:
                for dep_id in dependencies:
                    TaskDependency(
                        task_id=task.id,
                        depends_on_task_id=dep_id
                    ).save()
                self.db.commit_transaction(tx_id)
            except Exception:
                self.db.rollback_transaction(tx_id)
                raise
        
        print(f"✅ Task '{name}' added with ID: {task.id}")
        return task.id
    
    def list_tasks(self, status: Optional[TaskStatus] = None, 
                   priority: Optional[TaskPriority] = None) -> List[Task]:
        """List tasks with optional filtering"""
        query = QueryBuilder.select(Task)
        
        if status:
            query = query.where_eq("status", status.value)
        
        if priority:
            query = query.where_eq("priority", priority.value)
        
        query = query.order_by("priority", desc=True).order_by("created_at")
        return query.execute()
    
    def get_task(self, task_id: int) -> Optional[Task]:
        """Get a specific task"""
        return QueryBuilder.select(Task).where_eq("id", task_id).first()
    
    def update_task_status(self, task_id: int, status: TaskStatus, 
                         exit_code: Optional[int] = None,
                         stdout: str = "", stderr: str = ""):
        """Update task status and log execution"""
        task = self.get_task(task_id)
        if not task:
            raise ValueError(f"Task {task_id} not found")
        
        now = datetime.now()
        execution_id = f"exec_{task_id}_{int(now.timestamp())}"
        
        # Calculate duration
        duration = None
        if task.started_at and isinstance(task.started_at, datetime):
            duration = (now - task.started_at).total_seconds()
        
        # Log execution
        execution = TaskExecution(
            task_id=task_id,
            execution_id=execution_id,
            status=status.value,
            started_at=task.started_at or now,
            completed_at=now,
            exit_code=exit_code,
            stdout=stdout[:5000],  # Limit output size
            stderr=stderr[:5000],
            duration_seconds=duration,
            worker_id=self.worker_id
        )
        execution.save()
        
        # Update task
        task.status = status.value
        task.updated_at = now
        
        if status == TaskStatus.RUNNING:
            task.started_at = now
        elif status in [TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.CANCELLED]:
            task.completed_at = now
        
        task.save()
    
    def cancel_task(self, task_id: int):
        """Cancel a task"""
        task = self.get_task(task_id)
        if not task:
            raise ValueError(f"Task {task_id} not found")
        
        if task.status not in [TaskStatus.PENDING.value, TaskStatus.RUNNING.value]:
            raise ValueError(f"Cannot cancel task in {task.status} status")
        
        self.update_task_status(task_id, TaskStatus.CANCELLED)
        print(f"🚫 Task {task_id} cancelled")
    
    def get_dependencies(self, task_id: int) -> List[int]:
        """Get task dependencies"""
        deps = QueryBuilder.select(TaskDependency).where_eq("task_id", task_id).execute()
        return [dep.depends_on_task_id for dep in deps]
    
    def get_dependents(self, task_id: int) -> List[int]:
        """Get tasks that depend on this task"""
        deps = QueryBuilder.select(TaskDependency).where_eq("depends_on_task_id", task_id).execute()
        return [dep.task_id for dep in deps]
    
    def can_run_task(self, task: Task) -> bool:
        """Check if a task can run (dependencies satisfied)"""
        if task.status != TaskStatus.PENDING.value:
            return False
        
        # Check if scheduled time has arrived
        if task.scheduled_at:
            scheduled_at = task.scheduled_at
            if isinstance(scheduled_at, str):
                scheduled_at = datetime.fromisoformat(scheduled_at)
            if scheduled_at > datetime.now():
                return False
        
        # Check dependencies
        dependencies = self.get_dependencies(task.id)
        for dep_id in dependencies:
            dep_task = self.get_task(dep_id)
            if not dep_task or dep_task.status != TaskStatus.COMPLETED.value:
                return False
        
        return True
    
    def execute_task(self, task: Task) -> bool:
        """Execute a single task"""
        print(f"🚀 Executing task: {task.name}")
        
        # Update status to running
        self.update_task_status(task.id, TaskStatus.RUNNING)
        
        try:
            # Execute the command
            start_time = time.time()
            result = subprocess.run(
                task.command,
                shell=True,
                capture_output=True,
                text=True,
                timeout=task.timeout_seconds
            )
            duration = time.time() - start_time
            
            # Update based on result
            if result.returncode == 0:
                self.update_task_status(
                    task.id, 
                    TaskStatus.COMPLETED,
                    exit_code=result.returncode,
                    stdout=result.stdout,
                    stderr=result.stderr
                )
                print(f"✅ Task {task.name} completed successfully in {duration:.2f}s")
                return True
            else:
                self.update_task_status(
                    task.id,
                    TaskStatus.FAILED,
                    exit_code=result.returncode,
                    stdout=result.stdout,
                    stderr=result.stderr
                )
                print(f"❌ Task {task.name} failed with exit code {result.returncode}")
                return False
        
        except subprocess.TimeoutExpired:
            self.update_task_status(
                task.id,
                TaskStatus.FAILED,
                stderr=f"Task timed out after {task.timeout_seconds} seconds"
            )
            print(f"⏰ Task {task.name} timed out")
            return False
        
        except Exception as e:
            self.update_task_status(
                task.id,
                TaskStatus.FAILED,
                stderr=f"Unexpected error: {str(e)}"
            )
            print(f"💥 Task {task.name} failed with error: {e}")
            return False
    
    def retry_failed_tasks(self):
        """Retry tasks that have failed but have retries remaining"""
        failed_tasks = QueryBuilder.select(Task).where_eq("status", TaskStatus.FAILED.value).execute()
        
        for task in failed_tasks:
            if task.retry_count < task.max_retries:
                task.retry_count += 1
                task.status = TaskStatus.PENDING.value
                task.save()
                print(f"🔄 Task {task.name} queued for retry ({task.retry_count}/{task.max_retries})")
    
    def worker_loop(self):
        """Main worker loop"""
        print(f"🤖 Worker {self.worker_id} started")
        
        while self.running:
            try:
                # Get next runnable task
                runnable_tasks = []
                all_pending = QueryBuilder.select(Task).where_eq("status", TaskStatus.PENDING.value).execute()
                
                for task in all_pending:
                    if self.can_run_task(task):
                        runnable_tasks.append(task)
                
                if runnable_tasks:
                    # Sort by priority and execute the highest priority task
                    runnable_tasks.sort(key=lambda t: (-t.priority, t.created_at))
                    task = runnable_tasks[0]
                    self.execute_task(task)
                else:
                    # No tasks to run, wait a bit
                    time.sleep(1)
            
            except Exception as e:
                print(f"💥 Worker error: {e}")
                time.sleep(5)
        
        print(f"🤖 Worker {self.worker_id} stopped")
    
    def start_worker(self):
        """Start the background worker"""
        if self.running:
            print("⚠️ Worker is already running")
            return
        
        self.running = True
        self.worker_thread = threading.Thread(target=self.worker_loop, daemon=True)
        self.worker_thread.start()
        print("🚀 Task automation worker started")
    
    def stop_worker(self):
        """Stop the background worker"""
        if not self.running:
            print("⚠️ Worker is not running")
            return
        
        self.running = False
        if self.worker_thread:
            self.worker_thread.join(timeout=5)
        print("🛑 Task automation worker stopped")
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get system statistics"""
        stats = {}
        
        # Task counts by status
        for status in TaskStatus:
            count = QueryBuilder.select(Task).where_eq("status", status.value).count()
            stats[f"tasks_{status.value}"] = count
        
        # Execution statistics
        total_executions = QueryBuilder.select(TaskExecution).count()
        stats["total_executions"] = total_executions
        
        # Success rate
        completed = QueryBuilder.select(TaskExecution).where_eq("status", TaskStatus.COMPLETED.value).count()
        failed = QueryBuilder.select(TaskExecution).where_eq("status", TaskStatus.FAILED.value).count()
        
        if completed + failed > 0:
            stats["success_rate"] = completed / (completed + failed)
        else:
            stats["success_rate"] = 0.0
        
        # Average execution time
        completed_execs = QueryBuilder.select(TaskExecution).where_eq("status", TaskStatus.COMPLETED.value).execute()
        if completed_execs:
            avg_duration = sum(e.duration_seconds or 0 for e in completed_execs) / len(completed_execs)
            stats["avg_duration_seconds"] = avg_duration
        else:
            stats["avg_duration_seconds"] = 0.0
        
        # Database stats
        stats.update(self.db.get_index_stats())
        stats.update(self.db.get_transaction_stats())
        
        return stats
    
    def close(self):
        """Close the system"""
        self.stop_worker()
        self.db.close()


def main():
    """Demo of the task automation system"""
    system = TaskAutomationSystem()
    
    try:
        print("🎯 Task Automation System Demo")
        print("=" * 50)
        
        # Add some example tasks
        print("\n📝 Adding tasks...")
        
        # Simple tasks
        system.add_task(
            "Echo Hello",
            "echo 'Hello from task automation!'",
            "Simple echo command",
            priority=TaskPriority.LOW
        )
        
        system.add_task(
            "List Files",
            "ls -la",
            "List current directory",
            priority=TaskPriority.MEDIUM
        )
        
        # Task with dependency
        task1_id = system.add_task(
            "Create File",
            "echo 'Task automation demo' > demo.txt",
            "Create a demo file",
            priority=TaskPriority.HIGH
        )
        
        system.add_task(
            "Read File",
            "cat demo.txt",
            "Read the demo file",
            priority=TaskPriority.HIGH,
            dependencies=[task1_id]
        )
        
        # Task that might fail
        system.add_task(
            "Invalid Command",
            "this_command_does_not_exist",
            "This should fail",
            priority=TaskPriority.LOW
        )
        
        # List all tasks
        print("\n📋 All tasks:")
        tasks = system.list_tasks()
        for task in tasks:
            print(f"  {task.id}: {task.name} [{task.status}] (Priority: {task.priority})")
        
        # Start worker
        print("\n🚀 Starting worker...")
        system.start_worker()
        
        # Let it run for a bit
        print("⏳ Running tasks for 10 seconds...")
        time.sleep(10)
        
        # Show final status
        print("\n📊 Final task status:")
        tasks = system.list_tasks()
        for task in tasks:
            print(f"  {task.id}: {task.name} [{task.status}]")
        
        # Show statistics
        print("\n📈 System Statistics:")
        stats = system.get_statistics()
        for key, value in stats.items():
            if isinstance(value, float):
                print(f"  {key}: {value:.2f}")
            else:
                print(f"  {key}: {value}")
        
        # Show execution logs
        print("\n📝 Recent Executions:")
        executions = QueryBuilder.select(TaskExecution).order_by("started_at", desc=True).limit(5).execute()
        for exec in executions:
            task = system.get_task(exec.task_id)
            duration_str = f"{exec.duration_seconds:.2f}s" if exec.duration_seconds else "N/A"
            print(f"  {task.name if task else 'Unknown'}: {exec.status} ({duration_str})")
    
    finally:
        system.close()


if __name__ == "__main__":
    main()

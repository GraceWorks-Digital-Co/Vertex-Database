"""
Debug test to check what's in the database
"""

from database import Database, Model, StringField, IntegerField, FloatField, BooleanField, DateTimeField
from database.query import QueryBuilder
from datetime import datetime


class Product(Model):
    """Product model example"""
    table_name = "products"
    
    id = IntegerField(primary_key=True, nullable=False)
    name = StringField(max_length=100, nullable=False)
    description = StringField(max_length=500)
    price = FloatField(nullable=False)
    in_stock = BooleanField(default=True)
    created_at = DateTimeField(default=datetime.now)


def main():
    # Initialize database
    db = Database("debug_test.db")
    Model.set_database(db)
    
    # Create table
    Product.create_table()
    
    # Insert a single product
    product = Product(
        name="Test Product",
        description="Test description",
        price=99.99
    )
    product.save()
    print(f"Saved product: {product}")
    print(f"Product ID: {product.id}")
    
    # Query the product
    retrieved = QueryBuilder.select(Product).where_eq("name", "Test Product").first()
    if retrieved:
        print(f"Retrieved product: {retrieved}")
        print(f"Retrieved data: {retrieved.to_dict()}")
    else:
        print("No product found")
    
    # Check raw database content
    rows = db.execute("SELECT * FROM products")
    print("Raw database rows:")
    for row in rows:
        print(f"  {dict(row)}")
    
    db.close()


if __name__ == "__main__":
    main()

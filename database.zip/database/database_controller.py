"""
User-Friendly Database Controller
A simple Python application that makes database operations accessible to everyone
"""

import os
import sys
import sqlite3
from typing import List, Dict, Any, Optional
from pathlib import Path

# Add the database module to the path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from database import Database, Model, Field, StringField, IntegerField, FloatField, BooleanField, DateTimeField


class DatabaseController:
    """User-friendly database controller with interactive menu system"""
    
    def __init__(self, database_path: str = "user_database.db"):
        """Initialize the database controller"""
        self.database_path = database_path
        self.db = Database(database_path)
        self.running = True
    
    def clear_screen(self):
        """Clear the terminal screen"""
        os.system('cls' if os.name == 'nt' else 'clear')
    
    def print_header(self, title: str):
        """Print a formatted header"""
        self.clear_screen()
        print("=" * 60)
        print(f"  {title}")
        print("=" * 60)
        print()
    
    def wait_for_enter(self):
        """Wait for user to press Enter"""
        input("\nPress Enter to continue...")
    
    def get_user_choice(self, prompt: str, valid_choices: List[str] = None) -> str:
        """Get user input with validation"""
        while True:
            try:
                choice = input(prompt).strip().lower()
                if valid_choices is None or choice in valid_choices:
                    return choice
                else:
                    print(f"Please choose from: {', '.join(valid_choices)}")
            except KeyboardInterrupt:
                print("\nExiting...")
                sys.exit(0)
    
    def get_table_list(self) -> List[str]:
        """Get list of all tables in the database"""
        try:
            result = self.db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")
            return [row['name'] for row in result]
        except Exception as e:
            print(f"Error getting table list: {e}")
            return []
    
    def get_table_schema(self, table_name: str) -> List[Dict]:
        """Get schema information for a table"""
        try:
            result = self.db.execute(f"PRAGMA table_info({table_name})")
            return [dict(row) for row in result]
        except Exception as e:
            print(f"Error getting table schema: {e}")
            return []
    
    def get_table_data(self, table_name: str, limit: int = 20) -> List[Dict]:
        """Get data from a table"""
        try:
            result = self.db.execute(f"SELECT * FROM {table_name} LIMIT {limit}")
            return [dict(row) for row in result]
        except Exception as e:
            print(f"Error getting table data: {e}")
            return []
    
    def display_table_data(self, table_name: str):
        """Display table data in a readable format"""
        self.print_header(f"Data from table: {table_name}")
        
        data = self.get_table_data(table_name)
        if not data:
            print("No data found in this table.")
            self.wait_for_enter()
            return
        
        # Display column headers
        columns = list(data[0].keys())
        print("Columns:", " | ".join(columns))
        print("-" * 80)
        
        # Display rows
        for row in data:
            values = [str(row.get(col, 'NULL')) for col in columns]
            print(" | ".join(values))
        
        print(f"\nShowing {len(data)} rows")
        self.wait_for_enter()
    
    def display_table_schema(self, table_name: str):
        """Display table schema"""
        self.print_header(f"Schema for table: {table_name}")
        
        schema = self.get_table_schema(table_name)
        if not schema:
            print("Could not retrieve schema information.")
            self.wait_for_enter()
            return
        
        print(f"{'Column':<20} {'Type':<15} {'Not Null':<8} {'Primary Key':<11} {'Default':<15}")
        print("-" * 80)
        
        for column in schema:
            print(f"{column['name']:<20} {column['type']:<15} "
                  f"{'YES' if column['notnull'] else 'NO':<8} "
                  f"{'YES' if column['pk'] else 'NO':<11} "
                  f"{str(column['dflt_value']) if column['dflt_value'] else 'NULL':<15}")
        
        self.wait_for_enter()
    
    def create_table_interactive(self):
        """Interactive table creation"""
        self.print_header("Create New Table")
        
        table_name = input("Enter table name: ").strip()
        if not table_name:
            print("Table name cannot be empty!")
            self.wait_for_enter()
            return
        
        print("\nNow let's add columns to the table.")
        columns = []
        
        while True:
            print(f"\nColumn {len(columns) + 1}:")
            col_name = input("  Column name: ").strip()
            if not col_name:
                break
            
            print("  Data types: 1) Text  2) Integer  3) Float  4) Boolean  5) DateTime")
            type_choice = self.get_user_choice("  Choose data type (1-5): ", ['1', '2', '3', '4', '5'])
            
            type_mapping = {'1': 'TEXT', '2': 'INTEGER', '3': 'REAL', '4': 'BOOLEAN', '5': 'DATETIME'}
            col_type = type_mapping[type_choice]
            
            is_pk = self.get_user_choice("  Is this a primary key? (y/n): ", ['y', 'n']) == 'y'
            not_null = self.get_user_choice("  Can this be empty? (y/n): ", ['y', 'n']) == 'n'
            
            columns.append((col_name, col_type, is_pk, not_null))
            
            continue_choice = self.get_user_choice("  Add another column? (y/n): ", ['y', 'n'])
            if continue_choice == 'n':
                break
        
        if not columns:
            print("No columns defined. Table not created.")
            self.wait_for_enter()
            return
        
        # Create the table
        try:
            column_defs = []
            for col_name, col_type, is_pk, not_null in columns:
                constraints = []
                if not_null:
                    constraints.append("NOT NULL")
                if is_pk:
                    constraints.append("PRIMARY KEY")
                column_defs.append(f"{col_name} {col_type} {' '.join(constraints)}")
            
            create_sql = f"CREATE TABLE {table_name} ({', '.join(column_defs)})"
            self.db.execute(create_sql)
            
            print(f"\n✓ Table '{table_name}' created successfully!")
            self.wait_for_enter()
            
        except Exception as e:
            print(f"\n✗ Error creating table: {e}")
            self.wait_for_enter()
    
    def add_record_interactive(self, table_name: str):
        """Interactive record addition"""
        self.print_header(f"Add Record to: {table_name}")
        
        schema = self.get_table_schema(table_name)
        if not schema:
            print("Could not retrieve table schema.")
            self.wait_for_enter()
            return
        
        record_data = {}
        
        for column in schema:
            col_name = column['name']
            col_type = column['type']
            
            # Skip auto-increment primary keys
            if column['pk'] and col_type == 'INTEGER':
                continue
            
            prompt = f"Enter {col_name} ({col_type.lower()}): "
            if not column['notnull']:
                prompt += " (press Enter to skip): "
            
            value = input(prompt).strip()
            
            if value or column['notnull']:
                # Convert value based on type
                if col_type in ['INTEGER', 'REAL']:
                    try:
                        value = float(value) if col_type == 'REAL' else int(value)
                    except ValueError:
                        print(f"Invalid number for {col_name}. Using 0.")
                        value = 0
                elif col_type == 'BOOLEAN':
                    value = value.lower() in ['true', '1', 'yes', 'y']
                
                record_data[col_name] = value
        
        if not record_data:
            print("No data provided. Record not added.")
            self.wait_for_enter()
            return
        
        try:
            columns = list(record_data.keys())
            placeholders = ', '.join(['?' for _ in columns])
            values = list(record_data.values())
            
            insert_sql = f"INSERT INTO {table_name} ({', '.join(columns)}) VALUES ({placeholders})"
            self.db.execute(insert_sql, tuple(values))
            
            print("\n✓ Record added successfully!")
            self.wait_for_enter()
            
        except Exception as e:
            print(f"\n✗ Error adding record: {e}")
            self.wait_for_enter()
    
    def delete_record_interactive(self, table_name: str):
        """Interactive record deletion"""
        self.print_header(f"Delete Record from: {table_name}")
        
        # Show current records
        data = self.get_table_data(table_name, limit=10)
        if not data:
            print("No records found in this table.")
            self.wait_for_enter()
            return
        
        print("Current records:")
        for i, row in enumerate(data, 1):
            print(f"{i}. {dict(row)}")
        
        try:
            record_num = int(input(f"\nEnter record number to delete (1-{len(data)}): "))
            if not 1 <= record_num <= len(data):
                print("Invalid record number.")
                self.wait_for_enter()
                return
            
            record = data[record_num - 1]
            schema = self.get_table_schema(table_name)
            
            # Find primary key
            pk_column = None
            for col in schema:
                if col['pk']:
                    pk_column = col['name']
                    break
            
            if pk_column and pk_column in record:
                try:
                    delete_sql = f"DELETE FROM {table_name} WHERE {pk_column} = ?"
                    self.db.execute(delete_sql, (record[pk_column],))
                    print("\n✓ Record deleted successfully!")
                except Exception as e:
                    print(f"\n✗ Error deleting record: {e}")
            else:
                print("Could not identify primary key for deletion.")
            
        except ValueError:
            print("Invalid input. Please enter a number.")
        
        self.wait_for_enter()
    
    def execute_custom_query(self):
        """Execute custom SQL query"""
        self.print_header("Execute SQL Query")
        
        print("Enter your SQL query (or 'back' to return):")
        query = input("> ").strip()
        
        if query.lower() == 'back':
            return
        
        if not query:
            print("Empty query.")
            self.wait_for_enter()
            return
        
        try:
            result = self.db.execute(query)
            data = [dict(row) for row in result]
            
            if data:
                print(f"\nQuery executed successfully! {len(data)} rows returned:")
                print("-" * 80)
                
                # Display first few rows
                for i, row in enumerate(data[:10]):
                    print(f"Row {i + 1}: {row}")
                
                if len(data) > 10:
                    print(f"... and {len(data) - 10} more rows")
            else:
                print("Query executed successfully! No rows returned.")
                
        except Exception as e:
            print(f"✗ Query error: {e}")
        
        self.wait_for_enter()
    
    def show_database_stats(self):
        """Display database statistics"""
        self.print_header("Database Statistics")
        
        try:
            tables = self.get_table_list()
            
            print(f"Database: {self.database_path}")
            print(f"Number of tables: {len(tables)}")
            print()
            
            if tables:
                print("Table details:")
                print(f"{'Table':<20} {'Records':<10} {'Columns':<8}")
                print("-" * 40)
                
                for table in tables:
                    try:
                        # Get record count
                        count_result = self.db.execute(f"SELECT COUNT(*) as count FROM {table}")
                        record_count = count_result[0]['count']
                        
                        # Get column count
                        schema = self.get_table_schema(table)
                        column_count = len(schema)
                        
                        print(f"{table:<20} {record_count:<10} {column_count:<8}")
                    except Exception:
                        print(f"{table:<20} {'Error':<10} {'?':<8}")
            
            # Database file size
            if self.database_path != ":memory:" and Path(self.database_path).exists():
                size_bytes = Path(self.database_path).stat().st_size
                size_mb = size_bytes / (1024 * 1024)
                print(f"\nDatabase file size: {size_bytes} bytes ({size_mb:.2f} MB)")
            
        except Exception as e:
            print(f"Error getting statistics: {e}")
        
        self.wait_for_enter()
    
    def table_menu(self, table_name: str):
        """Menu for table-specific operations"""
        while True:
            self.print_header(f"Table Operations: {table_name}")
            
            print("1. View table data")
            print("2. View table schema")
            print("3. Add new record")
            print("4. Delete record")
            print("5. Back to main menu")
            
            choice = self.get_user_choice("Choose an option (1-5): ", ['1', '2', '3', '4', '5'])
            
            if choice == '1':
                self.display_table_data(table_name)
            elif choice == '2':
                self.display_table_schema(table_name)
            elif choice == '3':
                self.add_record_interactive(table_name)
            elif choice == '4':
                self.delete_record_interactive(table_name)
            elif choice == '5':
                break
    
    def main_menu(self):
        """Main application menu"""
        while self.running:
            self.print_header("Database Controller - Main Menu")
            
            print("1. View all tables")
            print("2. Create new table")
            print("3. Work with existing table")
            print("4. Execute SQL query")
            print("5. Database statistics")
            print("6. Exit")
            
            choice = self.get_user_choice("Choose an option (1-6): ", ['1', '2', '3', '4', '5', '6'])
            
            if choice == '1':
                self.show_all_tables()
            elif choice == '2':
                self.create_table_interactive()
            elif choice == '3':
                self.select_table_menu()
            elif choice == '4':
                self.execute_custom_query()
            elif choice == '5':
                self.show_database_stats()
            elif choice == '6':
                print("\nGoodbye!")
                self.running = False
    
    def show_all_tables(self):
        """Display all tables"""
        self.print_header("All Database Tables")
        
        tables = self.get_table_list()
        if not tables:
            print("No tables found in the database.")
        else:
            for i, table in enumerate(tables, 1):
                print(f"{i}. {table}")
        
        self.wait_for_enter()
    
    def select_table_menu(self):
        """Menu for selecting a table to work with"""
        tables = self.get_table_list()
        if not tables:
            print("No tables found. Create a table first.")
            self.wait_for_enter()
            return
        
        self.print_header("Select Table")
        
        for i, table in enumerate(tables, 1):
            print(f"{i}. {table}")
        
        try:
            choice = int(input(f"Select table (1-{len(tables)}): "))
            if 1 <= choice <= len(tables):
                self.table_menu(tables[choice - 1])
            else:
                print("Invalid selection.")
        except ValueError:
            print("Please enter a number.")
        
        self.wait_for_enter()
    
    def run(self):
        """Run the database controller"""
        print("Welcome to the Database Controller!")
        print("This tool helps you manage your database easily.")
        self.wait_for_enter()
        
        self.main_menu()


def main():
    """Main entry point"""
    print("Database Controller")
    print("==================")
    print()
    
    # Ask for database file
    db_path = input("Enter database file path (press Enter for default: user_database.db): ").strip()
    if not db_path:
        db_path = "user_database.db"
    
    # Create and run the controller
    controller = DatabaseController(db_path)
    controller.run()


if __name__ == "__main__":
    main()

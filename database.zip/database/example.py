"""
Example usage of the advanced Python database library
"""

from database import Database, Model, StringField, IntegerField, FloatField, BooleanField, DateTimeField
from database.query import QueryBuilder
from datetime import datetime


class User(Model):
    """User model example"""
    table_name = "users"
    
    id = IntegerField(primary_key=True, nullable=False)
    username = StringField(max_length=50, unique=True, nullable=False)
    email = StringField(max_length=100, unique=True, nullable=False)
    age = IntegerField(nullable=True)
    balance = FloatField(default=0.0)
    is_active = BooleanField(default=True)
    created_at = DateTimeField(default=datetime.now)


class Product(Model):
    """Product model example"""
    table_name = "products"
    
    id = IntegerField(primary_key=True, nullable=False)
    name = StringField(max_length=100, nullable=False)
    description = StringField(max_length=500)
    price = FloatField(nullable=False)
    in_stock = BooleanField(default=True)
    created_at = DateTimeField(default=datetime.now)


def main():
    # Initialize database
    db = Database("example.db")
    
    # Set database for all models
    Model.set_database(db)
    
    # Create tables
    print("Creating tables...")
    User.create_table()
    Product.create_table()
    
    # Example 1: Create users using model instances
    print("\n=== Creating Users ===")
    user1 = User(
        username="john_doe",
        email="john@example.com",
        age=30,
        balance=1000.50
    )
    user1.save()
    print(f"Created user: {user1}")
    
    user2 = User(
        username="jane_smith",
        email="jane@example.com",
        age=25,
        balance=2500.75
    )
    user2.save()
    print(f"Created user: {user2}")
    
    # Example 2: Batch insert using query builder
    print("\n=== Batch Insert Products ===")
    products_data = [
        {"name": "Laptop", "description": "High-performance laptop", "price": 1299.99},
        {"name": "Mouse", "description": "Wireless mouse", "price": 29.99},
        {"name": "Keyboard", "description": "Mechanical keyboard", "price": 89.99},
        {"name": "Monitor", "description": "27-inch 4K monitor", "price": 399.99}
    ]
    
    QueryBuilder.insert(Product).batch_values(products_data).execute()
    print(f"Inserted {len(products_data)} products")
    
    # Example 3: Query operations
    print("\n=== Query Operations ===")
    
    # Select all users
    all_users = QueryBuilder.select(User).execute()
    print(f"All users: {len(all_users)}")
    for user in all_users:
        print(f"  {user.username} - ${user.balance}")
    
    # Select with conditions
    expensive_products = QueryBuilder.select(Product).where_gt("price", 100).execute()
    print(f"\nExpensive products: {len(expensive_products)}")
    for product in expensive_products:
        print(f"  {product.name}: ${product.price}")
    
    # Example 4: Advanced queries
    print("\n=== Advanced Queries ===")
    
    # Complex WHERE conditions
    users_query = (QueryBuilder.select(User)
                   .where_gte("age", 25)
                   .where_lt("balance", 2000)
                   .order_by("age", desc=True)
                   .limit(1))
    young_user = users_query.first()
    if young_user:
        print(f"Young user with low balance: {young_user.username}")
    
    # Count operations
    user_count = QueryBuilder.select(User).count()
    product_count = QueryBuilder.select(Product).where_eq("in_stock", True).count()
    print(f"Total users: {user_count}")
    print(f"Products in stock: {product_count}")
    
    # Example 5: Update operations
    print("\n=== Update Operations ===")
    
    # Update single user
    user1.age = 31
    user1.balance = 1100.00
    user1.save()
    print(f"Updated user: {user1.username}")
    
    # Batch update using query builder
    updated_count = (QueryBuilder.update(Product)
                     .set("price", 1199.99)
                     .where_eq("name", "Laptop")
                     .execute())
    print(f"Updated {updated_count} product(s)")
    
    # Example 6: Delete operations
    print("\n=== Delete Operations ===")
    
    # Delete using model instance
    user2.delete()
    print(f"Deleted user: {user2.username}")
    
    # Delete using query builder
    deleted_count = (QueryBuilder.delete(Product)
                     .where_lt("price", 50)
                     .execute())
    print(f"Deleted {deleted_count} cheap product(s)")
    
    # Example 7: Transactions
    print("\n=== Transaction Example ===")
    
    try:
        with db.transaction() as conn:
            # Create new user
            new_user = User(
                username="transaction_user",
                email="trans@example.com",
                age=35,
                balance=500.00
            )
            new_user.save()
            
            # Update existing user
            user1.balance -= 100.00
            user1.save()
            
            print("Transaction completed successfully")
    except Exception as e:
        print(f"Transaction failed: {e}")
    
    # Example 8: Final state
    print("\n=== Final Database State ===")
    
    final_users = QueryBuilder.select(User).execute()
    final_products = QueryBuilder.select(Product).execute()
    
    print(f"Final users: {len(final_users)}")
    for user in final_users:
        print(f"  {user.username} (${user.balance})")
    
    print(f"Final products: {len(final_products)}")
    for product in final_products:
        print(f"  {product.name}: ${product.price}")
    
    # Close database
    db.close()


if __name__ == "__main__":
    main()

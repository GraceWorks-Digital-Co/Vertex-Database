# Advanced Python Database Library

A semi-advanced Python database library built on SQLite with ORM-like functionality, connection pooling, and a fluent query builder interface.

## Features

- **SQLite Backend**: Built on Python's built-in sqlite3 module
- **Connection Pooling**: Thread-safe connection pool for concurrent access
- **ORM-like Models**: Define models with field types and validation
- **Query Builder**: Fluent interface for building complex queries
- **Transaction Management**: Context manager for safe transactions
- **Field Validation**: Automatic validation for different field types
- **Batch Operations**: Efficient batch insert/update/delete operations
- **Advanced Queries**: Support for complex WHERE conditions, ordering, and pagination

## Quick Start

```python
from database import Database, Model, StringField, IntegerField, FloatField, BooleanField
from database.query import QueryBuilder
from datetime import datetime

# Define a model
class User(Model):
    table_name = "users"
    
    id = IntegerField(primary_key=True, nullable=False)
    username = StringField(max_length=50, unique=True, nullable=False)
    email = StringField(max_length=100, nullable=False)
    age = IntegerField(nullable=True)
    balance = FloatField(default=0.0)
    is_active = BooleanField(default=True)
    created_at = DateTimeField(default=datetime.now)

# Initialize database
db = Database("my_database.db")
Model.set_database(db)

# Create tables
User.create_table()

# Create and save a user
user = User(username="john_doe", email="john@example.com", age=30)
user.save()

# Query users
users = QueryBuilder.select(User).where_gte("age", 25).execute()
for user in users:
    print(f"{user.username}: {user.email}")

# Advanced queries
active_users = (QueryBuilder.select(User)
                .where_eq("is_active", True)
                .order_by("username")
                .limit(10)
                .execute())

# Batch insert
users_data = [
    {"username": "user1", "email": "user1@example.com", "age": 25},
    {"username": "user2", "email": "user2@example.com", "age": 30}
]
QueryBuilder.insert(User).batch_values(users_data).execute()

# Transactions
with db.transaction():
    user.balance -= 100
    user.save()
    # Other operations...

db.close()
```

## Field Types

- **StringField**: Text fields with max length validation
- **IntegerField**: Integer fields with type validation
- **FloatField**: Floating-point number fields
- **BooleanField**: Boolean fields (stored as INTEGER)
- **DateTimeField**: DateTime fields (stored as ISO strings)

### Field Options

- `nullable`: Whether the field can be NULL (default: True)
- `primary_key`: Whether this is a primary key field (default: False)
- `unique`: Whether the field should have a unique constraint (default: False)
- `default`: Default value or callable for the field
- `index`: Whether to create an index on this field (default: False)

## Query Builder

### SELECT Queries

```python
# Basic select
users = QueryBuilder.select(User).execute()

# With conditions
users = (QueryBuilder.select(User)
         .where_eq("is_active", True)
         .where_gt("age", 25)
         .execute())

# Ordering and pagination
users = (QueryBuilder.select(User)
         .order_by("username")
         .limit(10)
         .offset(20)
         .execute())

# Advanced conditions
users = (QueryBuilder.select(User)
         .where_in("id", [1, 2, 3])
         .where_like("username", "john%")
         .where_between("age", 25, 35)
         .execute())

# Count and existence
count = QueryBuilder.select(User).where_eq("is_active", True).count()
exists = QueryBuilder.select(User).where_eq("username", "john").exists()

# Get first match
user = QueryBuilder.select(User).where_eq("email", "john@example.com").first()
```

### INSERT Queries

```python
# Single insert
row_id = (QueryBuilder.insert(User)
          .values(username="new_user", email="new@example.com")
          .execute())

# Batch insert
data = [
    {"username": "user1", "email": "user1@example.com"},
    {"username": "user2", "email": "user2@example.com"}
]
QueryBuilder.insert(User).batch_values(data).execute()
```

### UPDATE Queries

```python
# Update records
count = (QueryBuilder.update(User)
         .set("is_active", False)
         .where_lt("last_login", "2023-01-01")
         .execute())

# Multiple fields
count = (QueryBuilder.update(User)
         .set_dict({"balance": 0, "is_active": False})
         .where_eq("username", "inactive_user")
         .execute())
```

### DELETE Queries

```python
# Delete records
count = (QueryBuilder.delete(User)
         .where_eq("is_active", False)
         .execute())
```

## Connection Pooling

The library includes a thread-safe connection pool for concurrent access:

```python
# Create database with custom pool size
db = Database("my_database.db", pool_size=20)

# Connections are automatically managed
# Each operation gets a connection from the pool
# Connections are returned to the pool after use
```

## Transaction Management

Use context managers for safe transaction handling:

```python
# Automatic commit/rollback
with db.transaction():
    user1.balance -= 100
    user1.save()
    
    user2.balance += 100
    user2.save()
    # If any exception occurs, the transaction is rolled back

# Manual transaction control
with db.get_connection() as conn:
    try:
        conn.execute("BEGIN")
        # Your operations here
        conn.commit()
    except Exception:
        conn.rollback()
        raise
```

## Error Handling

The library provides specific exception types:

- `DatabaseError`: Base exception for all database errors
- `ConnectionError`: Database connection failures
- `ValidationError`: Data validation failures
- `QueryError`: Query execution failures
- `TransactionError`: Transaction operation failures

## Testing

Run the test suite:

```bash
python test_database.py
```

The test suite covers:
- Model creation and validation
- CRUD operations
- Query builder functionality
- Transaction management
- Error handling

## Examples

See `example.py` for a comprehensive demonstration of all features.

## Requirements

This library uses only Python's standard library (sqlite3). No external dependencies are required.

Python 3.7+ is recommended for full type hint support.

## Architecture

The library is organized into several modules:

- `core.py`: Database connection management and pooling
- `models.py`: ORM-like model definitions and field types
- `query.py`: Query builder with fluent interface
- `exceptions.py`: Custom exception types

## Performance Considerations

- Connection pooling reduces connection overhead
- Batch operations minimize database round trips
- WAL journal mode enables concurrent reads/writes
- Foreign key constraints ensure data integrity
- Automatic indexing on frequently queried fields

## Limitations

- SQLite-based (not suitable for extremely high-concurrency scenarios)
- No migration system (manual schema management)
- Limited to SQLite feature set
- No relationship management (foreign keys must be handled manually)
